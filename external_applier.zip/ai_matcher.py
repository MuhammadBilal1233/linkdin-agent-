"""
ai_matcher.py — migrated to new google-genai SDK.
This file is kept for backward compatibility but the main agent
uses ai_engine.py. Both now use the same new SDK.
"""

import json
import os
from google import genai
from dotenv import load_dotenv

load_dotenv()

_api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
_client  = genai.Client(api_key=_api_key)
MODEL    = "gemini-2.0-flash-lite"


def _clean_json(raw: str) -> str:
    raw = (raw or "").strip()
    if "```json" in raw:
        raw = raw.split("```json", 1)[1].split("```", 1)[0]
    elif "```" in raw:
        raw = raw.split("```", 1)[1].split("```", 1)[0]
    return raw.strip()


def _call(prompt: str) -> str:
    response = _client.models.generate_content(model=MODEL, contents=prompt)
    return (response.text or "").strip()


def load_resume_data() -> dict:
    with open("resume_data.json", "r", encoding="utf-8") as f:
        return json.load(f)


def match_job_to_resume(job_title: str, job_description: str,
                        resume_data: dict) -> dict:
    resume_summary = f"""
Name: {resume_data.get('full_name')}
Title: {resume_data.get('current_job_title')}
Experience: {resume_data.get('years_of_experience')} years
Skills: {', '.join(resume_data.get('skills', [])[:20])}
Languages: {', '.join(resume_data.get('programming_languages', []))}
"""
    prompt = f"""Analyze if this job matches this candidate.

CANDIDATE:
{resume_summary}

JOB:
Title: {job_title}
Description: {job_description[:2000]}

Return ONLY valid JSON:
{{
    "match_score": <0-100>,
    "should_apply": <true/false>,
    "reason": "<one sentence>",
    "missing_skills": ["skill1"],
    "matching_skills": ["skill1"]
}}
Apply if match_score >= 65."""

    try:
        return json.loads(_clean_json(_call(prompt)) or "{}")
    except Exception as e:
        print(f"ai_matcher error: {e}")
        return {"match_score": 0, "should_apply": False,
                "reason": str(e), "missing_skills": [], "matching_skills": []}


def identify_missing_fields(form_fields: list, resume_data: dict) -> list:
    prompt = f"""Form fields: {json.dumps(form_fields)}
Resume: {json.dumps(resume_data, indent=2)[:2500]}

Return ONLY JSON array:
[{{"field_label":"","can_answer":true,"answer":"","needs_human":false}}]"""
    try:
        return json.loads(_clean_json(_call(prompt)) or "[]")
    except Exception:
        return []


def extract_job_details_from_post(post_text: str) -> dict:
    prompt = f"""Extract job details from this LinkedIn post.

POST: {post_text[:2500]}

Return ONLY JSON:
{{
    "is_job_posting": true/false,
    "job_title": "title or null",
    "company_name": "company or null",
    "recruiter_name": "name or null",
    "email_to_apply": "email or null",
    "external_link": "url or null",
    "location": "location or null",
    "job_description": "description or null",
    "application_method": "email/link/direct/unclear"
}}"""
    try:
        return json.loads(_clean_json(_call(prompt)) or "{}")
    except Exception:
        return {"is_job_posting": False}


extract_job_from_post = extract_job_details_from_post
