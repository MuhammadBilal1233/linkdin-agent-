"""
Fills external job application forms.
Detects failures (CAPTCHA, login walls) and notifies WhatsApp.

FIXES:
1. Removed --remote-debugging-port — caused port conflict on second run
   ("session not created: unable to connect to renderer")
2. Uses undetected-chromedriver to avoid bot detection on application sites
3. Uses a temp profile dir (unique per run) so no conflict with linkedin_reader
"""

import time
import random
import os
import shutil
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException, WebDriverException

try:
    import undetected_chromedriver as uc
    UC_AVAILABLE = True
except ImportError:
    UC_AVAILABLE = False
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from webdriver_manager.chrome import ChromeDriverManager

from dotenv import load_dotenv
from ai_engine import analyze_form_fields
from database import get_known_answer, add_pending_question
from whatsapp_handler import (
    notify_external_applied,
    notify_external_failed,
    ask_for_missing_info,
)
from config import RESUME_PDF_PATH

load_dotenv()


def _delay(a=1, b=3):
    time.sleep(random.uniform(a, b))


def create_driver():
    """
    Creates a Chrome instance for filling external forms.
    Uses a unique temp directory per run to avoid port/profile conflicts
    with the LinkedIn browser instance.
    """
    # Fixed named profile dir — cleared each run to avoid stale Chrome profile locks
    # Uses a different dir than linkedin_reader to avoid conflicts
    CHROME_PROFILE_DIR = os.path.join(os.path.dirname(__file__), ".chrome_profile_ext")
    if os.path.exists(CHROME_PROFILE_DIR):
        # Retry cleanup — Windows may still hold file handles briefly after taskkill
        for attempt in range(5):
            try:
                shutil.rmtree(CHROME_PROFILE_DIR)
                break
            except (PermissionError, OSError):
                for lockfile in ("DevToolsActivePort", "SingletonLock",
                                 "SingletonCookie", "SingletonSocket"):
                    try:
                        os.remove(os.path.join(CHROME_PROFILE_DIR, lockfile))
                    except OSError:
                        pass
                time.sleep(1)
        if os.path.exists(CHROME_PROFILE_DIR):
            shutil.rmtree(CHROME_PROFILE_DIR, ignore_errors=True)
    os.makedirs(CHROME_PROFILE_DIR, exist_ok=True)

    if UC_AVAILABLE:
        options = uc.ChromeOptions()
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1366,768")
        # NO --remote-debugging-port — caused session not created error
        driver = uc.Chrome(
            options=options,
            user_data_dir=CHROME_PROFILE_DIR,
            headless=False,
        )
        return driver
    else:
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.chrome.options import Options
        from webdriver_manager.chrome import ChromeDriverManager

        options = Options()
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        # NO --remote-debugging-port — caused port conflict on second run
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_argument(f"--user-data-dir={CHROME_PROFILE_DIR}")
        options.add_argument("--window-size=1366,768")
        options.add_argument("--disable-background-timer-throttling")
        service = Service(ChromeDriverManager().install())
        driver  = webdriver.Chrome(service=service, options=options)
        driver.execute_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )
        return driver


def _detect_failure_reason(driver) -> str:
    page_text  = driver.page_source.lower()
    page_title = driver.title.lower()

    for signal in ["captcha", "recaptcha", "hcaptcha", "i am not a robot",
                   "verify you are human", "cloudflare", "just a moment"]:
        if signal in page_text or signal in page_title:
            return "captcha"

    for signal in ["sign in to apply", "login to apply", "create an account",
                   "register to apply", "please log in", "you must be logged in"]:
        if signal in page_text:
            return "login_required"

    if any(x in page_title for x in ["404", "not found", "error"]):
        return "page_not_found"

    for signal in ["job no longer available", "position has been filled",
                   "posting has expired", "this job is no longer accepting"]:
        if signal in page_text:
            return "job_expired"

    return "submit_failed"


def _collect_fields(driver) -> list:
    fields = []
    selectors = (
        "input[type='text'], input[type='email'], input[type='tel'], "
        "input[type='number'], input[type='url'], textarea"
    )
    for el in driver.find_elements(By.CSS_SELECTOR, selectors):
        try:
            if not el.is_displayed():
                continue
            label = ""
            fid = el.get_attribute("id")
            if fid:
                try:
                    lbl = driver.find_element(By.CSS_SELECTOR, f"label[for='{fid}']")
                    label = lbl.text.strip()
                except Exception:
                    pass
            if not label:
                label = (
                    el.get_attribute("placeholder") or
                    el.get_attribute("aria-label") or
                    el.get_attribute("name") or
                    "Unknown"
                )
            val = el.get_attribute("value") or ""
            fields.append({"element": el, "label": label, "empty": not val.strip()})
        except Exception:
            pass
    return fields


def _upload_resume(driver) -> bool:
    abs_path = os.path.abspath(RESUME_PDF_PATH)
    for sel in [
        "input[type='file'][accept*='pdf']",
        "input[type='file'][accept*='.pdf']",
        "input[type='file']",
    ]:
        for inp in driver.find_elements(By.CSS_SELECTOR, sel):
            try:
                driver.execute_script("arguments[0].style.display='block';", inp)
                inp.send_keys(abs_path)
                _delay(1, 2)
                print("✅ Resume uploaded")
                return True
            except Exception:
                continue
    return False


def _click_submit(driver) -> bool:
    for sel in ["button[type='submit']", "input[type='submit']"]:
        try:
            btn = driver.find_element(By.CSS_SELECTOR, sel)
            if btn.is_displayed() and btn.is_enabled():
                btn.click()
                _delay(2, 3)
                return True
        except Exception:
            pass
    for text in ["Submit Application", "Submit", "Apply Now", "Apply",
                 "Send Application", "Complete Application"]:
        for btn in driver.find_elements(By.TAG_NAME, "button"):
            try:
                if text.lower() in btn.text.lower() and btn.is_displayed():
                    btn.click()
                    _delay(2, 3)
                    return True
            except Exception:
                pass
    return False


def apply_external(url: str,
                    job_title: str,
                    company: str,
                    job_id: str,
                    resume_data: dict,
                    match_result: dict = None,
                    approved_by_user: bool = False) -> dict:
    score = match_result.get("match_score", 0) if match_result else 0
    print(f"🔗 External apply: {job_title} @ {company} (score: {score}%)")

    result = {
        "success": False, "fields_filled": 0,
        "pending_questions": 0, "fail_reason": None, "url": url,
    }

    driver = create_driver()

    try:
        driver.get(url)
        _delay(3, 5)

        early = _detect_failure_reason(driver)
        if early in ("captcha", "login_required", "page_not_found", "job_expired"):
            result["fail_reason"] = early
            notify_external_failed(job_title, company, url, early, score)
            return result

        _upload_resume(driver)

        fields     = _collect_fields(driver)
        emp_labels = [f["label"] for f in fields if f["empty"]]

        if emp_labels:
            known = {}
            for lbl in emp_labels:
                ans = get_known_answer(lbl)
                if ans:
                    known[lbl] = ans
            ai_answers = analyze_form_fields(emp_labels, resume_data, known)

            for field in fields:
                if not field["empty"]:
                    continue
                ai_ans = next(
                    (a for a in ai_answers
                     if a.get("field_label", "").lower() == field["label"].lower()),
                    None,
                )
                if not ai_ans:
                    continue
                if ai_ans.get("needs_human"):
                    qid = add_pending_question(
                        job_id, job_title, company, field["label"], field["label"]
                    )
                    ask_for_missing_info(job_title, company, field["label"], qid)
                    result["pending_questions"] += 1
                    continue
                answer = ai_ans.get("answer")
                if not answer:
                    continue
                try:
                    el = field["element"]
                    el.clear()
                    for ch in str(answer):
                        el.send_keys(ch)
                        time.sleep(random.uniform(0.03, 0.09))
                    result["fields_filled"] += 1
                    _delay(0.2, 0.5)
                except Exception:
                    pass

        if result["pending_questions"] > 0:
            result["fail_reason"] = f"waiting_for_{result['pending_questions']}_answers"
            notify_external_failed(
                job_title, company, url,
                f"Waiting for {result['pending_questions']} answers", score,
            )
            return result

        if _detect_failure_reason(driver) == "captcha":
            result["fail_reason"] = "captcha"
            notify_external_failed(job_title, company, url, "captcha", score)
            return result

        submitted = _click_submit(driver)

        if submitted:
            result["success"] = True
            print(f"✅ Submitted: {job_title}")
            recruiter = match_result.get("recruiter", "") if match_result else ""
            notify_external_applied(
                job_title, company, recruiter, url,
                score, result["fields_filled"],
                approved_by_user=approved_by_user,
            )
        else:
            result["fail_reason"] = _detect_failure_reason(driver) or "submit_failed"
            notify_external_failed(job_title, company, url, result["fail_reason"], score)

    except Exception as e:
        result["fail_reason"] = str(e)[:100]
        notify_external_failed(job_title, company, url, result["fail_reason"], score)

    finally:
        try:
            driver.quit()
        except Exception:
            pass

    return result
