"""
Sends resume via Gmail SMTP.
BUG FIX: approved_by_user was used on line 115 but never declared
         as a function parameter — caused NameError at runtime.
         Added approved_by_user: bool = False to the signature.
"""

import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from dotenv import load_dotenv

from ai_engine import generate_cover_letter
from whatsapp_handler import notify_email_sent, notify_email_failed
from config import RESUME_PDF_PATH

load_dotenv()

YOUR_EMAIL   = os.getenv("YOUR_EMAIL")
APP_PASSWORD = os.getenv("YOUR_EMAIL_APP_PASSWORD") or os.getenv("YOUR_EMAIL_PASSWORD")


def send_resume_email(to_email: str,
                       recruiter_name: str,
                       job_title: str,
                       company_name: str,
                       job_description: str,
                       resume_data: dict,
                       match_result: dict = None,
                       approved_by_user: bool = False) -> bool:   # ← BUG FIX: added param
    """
    Send personalised resume email with AI cover letter.
    Notifies WhatsApp on success or failure.
    """
    your_name     = resume_data.get("full_name", "Applicant")
    your_phone    = resume_data.get("phone", "")
    your_linkedin = resume_data.get("linkedin_url", "")

    cover_body = generate_cover_letter(
        job_title, company_name, job_description, resume_data
    )

    subject  = f"Application for {job_title} — {your_name}"
    greeting = (
        f"Dear {recruiter_name},"
        if recruiter_name and len(recruiter_name.strip()) > 2
        else "Dear Hiring Manager,"
    )

    full_body = (
        f"{greeting}\n\n"
        f"{cover_body}\n\n"
        f"Best regards,\n"
        f"{your_name}\n"
        f"📞 {your_phone}\n"
        f"📧 {YOUR_EMAIL}\n"
        + (f"🔗 {your_linkedin}\n" if your_linkedin else "")
    )

    msg = MIMEMultipart()
    msg["From"]     = YOUR_EMAIL
    msg["To"]       = to_email
    msg["Subject"]  = subject
    msg["Reply-To"] = YOUR_EMAIL
    msg.attach(MIMEText(full_body, "plain"))

    resume_filename = f"Resume_{your_name.replace(' ', '_')}.pdf"
    try:
        with open(RESUME_PDF_PATH, "rb") as f:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header(
                "Content-Disposition",
                f'attachment; filename="{resume_filename}"'
            )
            msg.attach(part)
    except FileNotFoundError:
        reason = f"Resume PDF not found at {RESUME_PDF_PATH}"
        print(f"❌ {reason}")
        notify_email_failed(job_title, company_name, to_email, reason)
        return False

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(YOUR_EMAIL, APP_PASSWORD)
            server.sendmail(YOUR_EMAIL, to_email, msg.as_string())

        print(f"✅ Email sent → {to_email} | {job_title} @ {company_name}")

        matching_skills = []
        score = 0
        if match_result:
            matching_skills = (
                match_result.get("skills", {}).get("candidate_has", [])
                or match_result.get("matching_skills", [])
            )
            score = match_result.get("match_score", 0)

        notify_email_sent(
            job_title=job_title,
            company=company_name,
            recruiter=recruiter_name,
            email_to=to_email,
            match_score=score,
            matching_skills=matching_skills,
            cover_letter_preview=cover_body,
            approved_by_user=approved_by_user,   # ← now works
        )
        return True

    except smtplib.SMTPAuthenticationError:
        reason = "Gmail auth failed — check App Password in .env"
        print(f"❌ {reason}")
        notify_email_failed(job_title, company_name, to_email, reason)
        return False

    except smtplib.SMTPRecipientsRefused:
        reason = f"Email address rejected: {to_email}"
        print(f"❌ {reason}")
        notify_email_failed(job_title, company_name, to_email, reason)
        return False

    except Exception as e:
        reason = str(e)
        print(f"❌ Email error: {reason}")
        notify_email_failed(job_title, company_name, to_email, reason)
        return False
