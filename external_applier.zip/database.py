
"""
Agent memory — SQLite database.
New in this version:
  - approval_queue  : jobs waiting for your YES/NO on WhatsApp
  - applications    : detailed post-apply tracking record
"""

import sqlite3
import json
from datetime import datetime
from typing import Optional
from config import DATABASE_PATH, BLOCKED_COMPANIES


def get_conn():
    return sqlite3.connect(DATABASE_PATH, check_same_thread=False)


def init_database():
    conn = get_conn()
    c = conn.cursor()

    # Every job the agent has seen
    c.execute("""
        CREATE TABLE IF NOT EXISTS jobs_seen (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id      TEXT    UNIQUE NOT NULL,
            job_title   TEXT,
            company     TEXT,
            location    TEXT,
            url         TEXT,
            source      TEXT,
            method      TEXT,
            match_score INTEGER,
            first_seen  DATETIME,
            applied     INTEGER DEFAULT 0,
            applied_at  DATETIME,
            skipped     INTEGER DEFAULT 0,
            skip_reason TEXT
        )
    """)

    # ── NEW: Jobs waiting for WhatsApp YES/NO approval ───────
    c.execute("""
        CREATE TABLE IF NOT EXISTS approval_queue (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id          TEXT    UNIQUE NOT NULL,
            job_title       TEXT,
            company         TEXT,
            location        TEXT,
            url             TEXT,
            apply_method    TEXT,   -- 'email' or 'external'
            apply_target    TEXT,   -- email address or form URL
            job_description TEXT,
            recruiter_name  TEXT,
            match_score     INTEGER,
            matching_skills TEXT,   -- JSON list
            missing_skills  TEXT,   -- JSON list
            asked_at        DATETIME,
            decision        TEXT,   -- NULL / 'yes' / 'no' / 'timeout'
            decided_at      DATETIME
        )
    """)

    # ── NEW: Detailed application tracking ───────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id          TEXT,
            job_title       TEXT,
            company         TEXT,
            location        TEXT,
            recruiter_name  TEXT,
            apply_method    TEXT,   -- 'email' or 'external'
            apply_target    TEXT,   -- email or URL
            match_score     INTEGER,
            matching_skills TEXT,
            missing_skills  TEXT,
            cover_letter    TEXT,
            status          TEXT,   -- 'sent' / 'failed'
            fail_reason     TEXT,
            applied_at      DATETIME,
            approved_by_user INTEGER DEFAULT 0  -- 1 if user said YES
        )
    """)

    # Learned answers from your WhatsApp replies
    c.execute("""
        CREATE TABLE IF NOT EXISTS known_answers (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            question_normalized TEXT    UNIQUE,
            question_original   TEXT,
            answer              TEXT    NOT NULL,
            times_used          INTEGER DEFAULT 0,
            first_saved         DATETIME,
            last_used           DATETIME
        )
    """)

    # Questions waiting for your WhatsApp reply
    c.execute("""
        CREATE TABLE IF NOT EXISTS pending_questions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id      TEXT,
            job_title   TEXT,
            company     TEXT,
            question    TEXT,
            field_name  TEXT,
            asked_at    DATETIME,
            answered    INTEGER DEFAULT 0,
            answer      TEXT,
            answered_at DATETIME
        )
    """)

    conn.commit()
    conn.close()
    print("✅ Database ready")


# ── Company block check ──────────────────────────────────────

def is_company_blocked(company_name: str) -> bool:
    """
    Returns True if this company is in the blocked list.
    Case-insensitive, partial match.
    e.g. "CureMD Healthcare" matches block entry "curemd"
    """
    if not company_name:
        return False
    name_lower = company_name.lower()
    for blocked in BLOCKED_COMPANIES:
        if blocked.lower() in name_lower:
            return True
    return False


# ── Job tracking ─────────────────────────────────────────────

def has_seen_job(job_id: str) -> bool:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT id FROM jobs_seen WHERE job_id=?", (job_id,))
    r = c.fetchone()
    conn.close()
    return r is not None


def save_job(job_id, title, company, location, url,
             source, method, match_score):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO jobs_seen
        (job_id,job_title,company,location,url,
         source,method,match_score,first_seen)
        VALUES (?,?,?,?,?,?,?,?,?)
    """, (job_id, title, company, location, url,
          source, method, match_score, datetime.now()))
    conn.commit()
    conn.close()


def mark_applied(job_id: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO jobs_seen (job_id, first_seen)
        VALUES (?, ?)
    """, (job_id, datetime.now()))
    c.execute("""
        UPDATE jobs_seen
        SET applied=1, applied_at=?
        WHERE job_id=?
    """, (datetime.now(), job_id))
    conn.commit()
    conn.close()


def mark_skipped(job_id: str, reason: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO jobs_seen (job_id, first_seen)
        VALUES (?, ?)
    """, (job_id, datetime.now()))
    c.execute("""
        UPDATE jobs_seen
        SET skipped=1, skip_reason=?
        WHERE job_id=?
    """, (reason, job_id))
    conn.commit()
    conn.close()


# ── Approval queue ───────────────────────────────────────────

def add_to_approval_queue(job_id, title, company, location,
                           url, apply_method, apply_target,
                           description, recruiter,
                           match_score, matching_skills,
                           missing_skills) -> bool:
    """
    Add a job to the approval queue.
    Returns False if job_id already queued.
    """
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute("""
            INSERT INTO approval_queue
            (job_id,job_title,company,location,url,
             apply_method,apply_target,job_description,
             recruiter_name,match_score,matching_skills,
             missing_skills,asked_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            job_id, title, company, location, url,
            apply_method, apply_target, description,
            recruiter, match_score,
            json.dumps(matching_skills),
            json.dumps(missing_skills),
            datetime.now()
        ))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False  # Already in queue
    finally:
        conn.close()


def get_pending_approvals() -> list:
    """Return all queue items waiting for a decision"""
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        SELECT id, job_id, job_title, company, location,
               url, apply_method, apply_target,
               job_description, recruiter_name,
               match_score, matching_skills, missing_skills,
               asked_at
        FROM approval_queue
        WHERE decision IS NULL
        ORDER BY asked_at ASC
    """)
    rows = c.fetchall()
    conn.close()

    results = []
    for row in rows:
        results.append({
            "queue_id":       row[0],
            "job_id":         row[1],
            "job_title":      row[2],
            "company":        row[3],
            "location":       row[4],
            "url":            row[5],
            "apply_method":   row[6],
            "apply_target":   row[7],
            "description":    row[8],
            "recruiter":      row[9],
            "match_score":    row[10],
            "matching_skills": json.loads(row[11] or "[]"),
            "missing_skills":  json.loads(row[12] or "[]"),
            "asked_at":       row[13],
        })
    return results


def get_approval_decision(job_id: str) -> Optional[str]:
    """
    Returns: 'yes', 'no', 'timeout', or None (still waiting)
    """
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        SELECT decision FROM approval_queue
        WHERE job_id=?
    """, (job_id,))
    r = c.fetchone()
    conn.close()
    return r[0] if r else None


def set_approval_decision(queue_id: int, decision: str):
    """Record YES or NO decision"""
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        UPDATE approval_queue
        SET decision=?, decided_at=?
        WHERE id=?
    """, (decision.lower(), datetime.now(), queue_id))
    conn.commit()
    conn.close()


def set_approval_decision_by_job(job_id: str, decision: str):
    """Record decision by job_id (used when processing replies)"""
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        UPDATE approval_queue
        SET decision=?, decided_at=?
        WHERE job_id=? AND decision NOT IN ('yes', 'no')
    """, (decision.lower(), datetime.now(), job_id))
    conn.commit()
    conn.close()


def expire_old_approvals(timeout_seconds: int):
    """Mark unanswered approvals as timed-out"""
    from datetime import timedelta
    cutoff = datetime.now() - timedelta(seconds=timeout_seconds)
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        UPDATE approval_queue
        SET decision='timeout', decided_at=?
        WHERE decision IS NULL AND asked_at < ?
    """, (datetime.now(), cutoff))
    changed = c.rowcount
    conn.commit()
    conn.close()
    return changed


# ── Detailed application log ─────────────────────────────────

def log_application(job_id, title, company, location,
                     recruiter, method, target,
                     match_score, matching_skills,
                     missing_skills, cover_letter,
                     status, fail_reason=None,
                     approved_by_user=False):
    """
    Save a full record of every application attempt.
    This is your permanent application history.
    """
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT INTO applications
        (job_id, job_title, company, location, recruiter_name,
         apply_method, apply_target, match_score,
         matching_skills, missing_skills, cover_letter,
         status, fail_reason, applied_at, approved_by_user)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        job_id, title, company, location, recruiter,
        method, target, match_score,
        json.dumps(matching_skills),
        json.dumps(missing_skills),
        cover_letter, status, fail_reason,
        datetime.now(), 1 if approved_by_user else 0
    ))
    conn.commit()
    conn.close()


def get_application_history(limit=100) -> list:
    """Return recent application history"""
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        SELECT job_title, company, location, apply_method,
               apply_target, match_score, status,
               fail_reason, applied_at, approved_by_user
        FROM applications
        ORDER BY applied_at DESC
        LIMIT ?
    """, (limit,))
    rows = c.fetchall()
    conn.close()
    return rows


# ── Known answers ────────────────────────────────────────────

def normalize_question(q: str) -> str:
    import re
    q = q.lower().strip()
    q = re.sub(r'[^\w\s]', '', q)
    q = re.sub(r'\s+', ' ', q)
    return q[:150]


def get_known_answer(question: str) -> Optional[str]:
    key = normalize_question(question)
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "SELECT answer FROM known_answers WHERE question_normalized=?",
        (key,)
    )
    r = c.fetchone()
    if r:
        c.execute("""
            UPDATE known_answers
            SET times_used=times_used+1, last_used=?
            WHERE question_normalized=?
        """, (datetime.now(), key))
        conn.commit()
    conn.close()
    return r[0] if r else None


def save_answer(question: str, answer: str):
    key = normalize_question(question)
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT OR REPLACE INTO known_answers
        (question_normalized, question_original, answer,
         times_used, first_saved, last_used)
        VALUES (?,?,?,0,?,?)
    """, (key, question, answer, datetime.now(), datetime.now()))
    conn.commit()
    conn.close()


def add_pending_question(job_id, title, company,
                          question, field_name) -> int:
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT INTO pending_questions
        (job_id,job_title,company,question,field_name,asked_at)
        VALUES (?,?,?,?,?,?)
    """, (job_id, title, company, question, field_name, datetime.now()))
    conn.commit()
    qid = c.lastrowid
    conn.close()
    return qid


def get_unanswered_questions() -> list:
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        SELECT id,job_id,job_title,company,question,field_name
        FROM pending_questions
        WHERE answered=0
        ORDER BY asked_at ASC
    """)
    rows = c.fetchall()
    conn.close()
    return rows


def answer_question(qid: int, answer: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT question FROM pending_questions WHERE id=?", (qid,))
    r = c.fetchone()
    if r:
        c.execute("""
            UPDATE pending_questions
            SET answered=1, answer=?, answered_at=?
            WHERE id=?
        """, (answer, datetime.now(), qid))
        conn.commit()
        save_answer(r[0], answer)
    conn.close()


if __name__ == "__main__":
    init_database()

# ── Compatibility aliases for older scripts ─────────────────

job_already_applied = has_seen_job
get_learned_answer = get_known_answer


def save_application(job_id, title, company, recruiter_name, method, status, apply_target, email_sent_to=None, match_score=0, matching_skills=None, missing_skills=None, cover_letter="", approved_by_user=False, fail_reason=None):
    """Backward-compatible wrapper around log_application."""
    matching_skills = matching_skills or []
    missing_skills = missing_skills or []
    log_application(
        job_id=job_id,
        title=title,
        company=company,
        location="",
        recruiter=recruiter_name,
        method=method,
        target=apply_target,
        match_score=match_score,
        matching_skills=matching_skills,
        missing_skills=missing_skills,
        cover_letter=cover_letter,
        status=status,
        fail_reason=fail_reason,
        approved_by_user=approved_by_user,
    )
    if status in ("applied", "sent"):
        mark_applied(job_id)


def save_pending_question(job_id, title, company, question=None, field_name=None):
    """Backward-compatible wrapper for older scripts."""
    question = question or field_name or title
    field_name = field_name or title
    return add_pending_question(job_id, title, company, question, field_name)
