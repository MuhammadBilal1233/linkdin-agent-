"""
WhatsApp via Green-API (free tier).
New in this version:
  - send_approval_request()  : ask YES/NO before applying
  - notify_application_saved(): detailed record after each apply
  - Reply processing handles: ANS, YES, NO commands
"""

import requests
import os
import urllib3
from dotenv import load_dotenv
from database import (
    answer_question, save_answer,
    set_approval_decision_by_job
)

load_dotenv()

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

INSTANCE_ID  = os.getenv("GREEN_API_ID_INSTANCE")
API_TOKEN    = os.getenv("GREEN_API_API_TOKEN")
YOUR_PHONE   = os.getenv("YOUR_WHATSAPP")
_GREEN_API_HOST = os.getenv("GREEN_API_URL", "https://7107.api.greenapi.com")
BASE         = f"{_GREEN_API_HOST}/waInstance{INSTANCE_ID}"

_VERIFY_SSL = os.getenv("VERIFY_SSL", "false").lower() in ("true", "1", "yes")

_session = requests.Session()
_session.verify = _VERIFY_SSL


def _send(text: str, phone: str = None) -> bool:
    phone = phone or YOUR_PHONE
    try:
        r = _session.post(
            f"{BASE}/sendMessage/{API_TOKEN}",
            json={"chatId": f"{phone}@c.us", "message": text},
            timeout=15
        )
        return r.status_code == 200
    except Exception as e:
        print(f"WhatsApp send error: {e}")
        return False


# ── Approval flow (Week 1 mode) ──────────────────────────────

def send_approval_request(job_id: str,
                           job_title: str,
                           company: str,
                           location: str,
                           url: str,
                           apply_method: str,
                           apply_target: str,
                           match_score: int,
                           matching_skills: list,
                           missing_skills: list,
                           recruiter: str = "") -> bool:
    """
    Send a WhatsApp message asking YES/NO before applying.
    User replies:
      YES <job_id>   → proceed with application
      NO  <job_id>   → skip this job
    """
    method_str = (
        f"📧 Email to: {apply_target}"
        if apply_method == "email"
        else f"🔗 External form: {apply_target}"
    )

    matching_str = (
        ", ".join(matching_skills[:5])
        if matching_skills else "—"
    )
    missing_str = (
        ", ".join(missing_skills[:3])
        if missing_skills else "None ✅"
    )

    msg = (
        f"🔔 *Approval Needed — Job Match Found*\n\n"
        f"💼 *Role:* {job_title}\n"
        f"🏢 *Company:* {company}\n"
        f"📍 *Location:* {location or 'Not specified'}\n"
        f"👤 *Recruiter:* {recruiter or 'Not listed'}\n"
        f"🎯 *Match Score:* {match_score}%\n\n"
        f"✅ *Your matching skills:*\n{matching_str}\n\n"
        f"⚠️ *Missing skills:*\n{missing_str}\n\n"
        f"📬 *How I will apply:*\n{method_str}\n\n"
        f"🔗 *View Job:* {url}\n\n"
        f"─────────────────\n"
        f"Reply:\n"
        f"*YES {job_id}* → Apply now\n"
        f"*NO {job_id}* → Skip this job\n"
        f"─────────────────\n"
        f"_No reply within 1 hour = auto-skip_"
    )
    return _send(msg)


def notify_approval_timeout(job_title: str,
                             company: str,
                             job_id: str) -> bool:
    """Notify when approval request timed out"""
    msg = (
        f"⏰ *Approval Timed Out — Skipped*\n\n"
        f"_{job_title}_ at _{company}_\n"
        f"No reply received within 1 hour.\n"
        f"Job was skipped.\n\n"
        f"Reply *YES {job_id}* now to still apply."
    )
    return _send(msg)


# ── Post-apply notifications ─────────────────────────────────

def notify_email_sent(job_title: str, company: str,
                       recruiter: str, email_to: str,
                       match_score: int,
                       matching_skills: list,
                       cover_letter_preview: str = "",
                       approved_by_user: bool = False) -> bool:
    """Full details notification after email is sent"""
    skills_str = (
        ", ".join(matching_skills[:5])
        if matching_skills else "N/A"
    )
    mode = "✅ You approved this" if approved_by_user else "🤖 Auto-applied"

    msg = (
        f"📧 *Resume Email Sent!*\n\n"
        f"💼 *Position:* {job_title}\n"
        f"🏢 *Company:* {company}\n"
        f"👤 *Recruiter:* {recruiter or 'Not listed'}\n"
        f"📬 *Sent to:* {email_to}\n"
        f"🎯 *Match Score:* {match_score}%\n"
        f"✅ *Matched skills:* {skills_str}\n"
        f"🔧 *Mode:* {mode}\n"
    )

    if cover_letter_preview:
        preview = cover_letter_preview[:150].replace("\n", " ")
        msg += f"\n📝 *Cover letter:*\n_{preview}..._\n"

    msg += "\n_Application sent ✉️_"
    return _send(msg)


def notify_external_applied(job_title: str, company: str,
                              recruiter: str, url: str,
                              match_score: int,
                              fields_filled: int,
                              approved_by_user: bool = False) -> bool:
    """Notification after successful external form submission"""
    mode = "✅ You approved this" if approved_by_user else "🤖 Auto-applied"
    msg = (
        f"🔗 *External Form Submitted!*\n\n"
        f"💼 *Position:* {job_title}\n"
        f"🏢 *Company:* {company}\n"
        f"👤 *Contact:* {recruiter or 'Not listed'}\n"
        f"🌐 *Form:* {url}\n"
        f"🎯 *Match Score:* {match_score}%\n"
        f"📝 *Fields filled:* {fields_filled}\n"
        f"🔧 *Mode:* {mode}\n\n"
        f"_Submitted successfully ✅_"
    )
    return _send(msg)


def notify_external_failed(job_title: str, company: str,
                             url: str, reason: str,
                             match_score: int) -> bool:
    """Notification when external form fails — includes manual link"""
    reason_map = {
        "captcha":        "CAPTCHA detected — needs human",
        "login_required": "Site requires login/account",
        "submit_failed":  "Submit button not found",
        "timeout":        "Page load timeout",
        "job_expired":    "Job posting has expired",
        "page_not_found": "Page not found (404),",
    }
    readable = reason
    for key, label in reason_map.items():
        if key in reason.lower():
            readable = label
            break

    msg = (
        f"⚠️ *External Form Failed*\n\n"
        f"💼 *Position:* {job_title}\n"
        f"🏢 *Company:* {company}\n"
        f"🎯 *Match Score:* {match_score}% ← worth applying!\n"
        f"❌ *Reason:* {readable}\n\n"
        f"👆 *Apply manually here:*\n{url}\n\n"
        f"_This job matched your profile — don't miss it!_"
    )
    return _send(msg)


def notify_email_failed(job_title: str, company: str,
                         email_to: str, reason: str) -> bool:
    msg = (
        f"❌ *Email Failed*\n\n"
        f"💼 _{job_title}_ at _{company}_\n"
        f"📬 Tried: {email_to}\n"
        f"⚠️ Reason: {reason}\n\n"
        f"_You may want to apply manually._"
    )
    return _send(msg)


def notify_company_blocked(job_title: str,
                            company: str) -> bool:
    """Notify when a job is skipped because it's your current company"""
    msg = (
        f"🚫 *Skipped — Current Company*\n\n"
        f"_{job_title}_ at _{company}_\n\n"
        f"This company is in your blocked list.\n"
        f"Agent will never apply here."
    )
    return _send(msg)


def ask_for_missing_info(job_title: str, company: str,
                          question: str,
                          question_id: int) -> bool:
    msg = (
        f"❓ *Info Needed*\n\n"
        f"Applying to: *{job_title}* at *{company}*\n\n"
        f"Form asks:\n*\"{question}\"*\n\n"
        f"Reply:\n`ANS {question_id} your answer`\n\n"
        f"_Example: `ANS {question_id} 5 years`_\n"
        f"_Saved permanently for future forms._"
    )
    return _send(msg)


def notify_shortlist_ready(count: int, file_path: str,
                            jobs: list = None) -> bool:
    jobs = jobs or []
    msg = (
        f"📋 *Easy Apply Shortlist — {count} jobs matched*\n"
        f"📍 Pakistan / Remote only\n"
        f"_Click each link → Easy Apply on LinkedIn_\n\n"
    )
    for i, j in enumerate(jobs[:10], 1):
        title   = j.get("title") or j.get("job_title", "Position")
        company = j.get("company") or j.get("company_name", "")
        url     = j.get("url", "")
        score   = j.get("match_score", 0)
        line = f"{i}. *{title}* @ {company} — {score}%"
        if url and url != "N/A":
            line += f"\n   🔗 {url}"
        msg += line + "\n\n"
    msg += "_Agent handles email + external forms automatically._"
    return _send(msg)


def notify_daily_summary(scanned: int, blocked: int,
                          location_skipped: int,
                          score_skipped: int,
                          matched: int,
                          pending_approval: int,
                          emails_sent: int,
                          emails_failed: int,
                          external_ok: int,
                          external_failed: int,
                          shortlist_count: int,
                          approval_mode: bool,
                          matched_jobs: list = None) -> bool:
    matched_jobs = matched_jobs or []
    mode_str = (
        "🔍 *Approval Mode ON* — You reviewed each job"
        if approval_mode
        else "🤖 *Auto Mode* — Agent applied directly"
    )
    msg = (
        f"📊 *Daily Summary*\n\n"
        f"{mode_str}\n\n"
        f"🔍 Scanned:              *{scanned}*\n"
        f"🚫 Blocked (your co):    *{blocked}*\n"
        f"📍 Wrong location:       *{location_skipped}*\n"
        f"📉 Low match score:      *{score_skipped}*\n"
        f"✅ Qualified:            *{matched}*\n"
        f"⏳ Awaiting your reply:  *{pending_approval}*\n\n"
        f"📧 Emails sent:          *{emails_sent}*\n"
        f"❌ Emails failed:        *{emails_failed}*\n"
        f"🔗 External done:        *{external_ok}*\n"
        f"⚠️ External failed:      *{external_failed}*\n"
        f"📋 Easy Apply shortlist: *{shortlist_count}*\n"
    )
    if matched_jobs:
        msg += "\n─────────────────\n"
        msg += f"*Matched Jobs ({len(matched_jobs)}):*\n"
        for i, j in enumerate(matched_jobs[:15], 1):
            title   = j.get("title", "Position")
            company = j.get("company", "")
            url     = j.get("url", "")
            score   = j.get("score", 0)
            method  = j.get("method", "")
            method_icon = "📋" if method == "easy_apply" else ("📧" if method == "email" else "🔗")
            line = f"{i}. {method_icon} *{title}* @ {company} ({score}%)"
            if url and url not in ("N/A", ""):
                line += f"\n   {url}"
            msg += line + "\n"
    return _send(msg)


# ── Reply processing ─────────────────────────────────────────

def receive_and_process_replies() -> dict:
    """
    Poll WhatsApp for incoming messages.
    Handles three reply types:
      YES <job_id>     → approve job application
      NO  <job_id>     → reject job application
      ANS <id> <text>  → answer a form field question

    Returns counts of each type processed.
    """
    counts = {"yes": 0, "no": 0, "ans": 0}

    for _ in range(30):   # Poll up to 30 queued notifications
        try:
            # ✅ FIXED: Increased timeout to 30 seconds to prevent early drops
            r = _session.get(
                f"{BASE}/receiveNotification/{API_TOKEN}",
                timeout=30
            )
            if r.status_code != 200:
                break

            data = r.json()
            if not data:
                break

            receipt_id = data.get("receiptId")
            body       = data.get("body", {})

            # Always delete from queue immediately
            if receipt_id:
                _session.delete(
                    f"{BASE}/deleteNotification/{API_TOKEN}/{receipt_id}",
                    timeout=15
                )

            if body.get("typeWebhook") != "incomingMessageReceived":
                continue

            text = (
                body
                .get("messageData", {})
                .get("textMessageData", {})
                .get("textMessage", "")
                .strip()
            )
            if not text:
                continue

            upper = text.upper()

            # ── YES <job_id> ───────────────────────────────────
            if upper.startswith("YES "):
                job_id = text.split(" ", 1)[1].strip()
                set_approval_decision_by_job(job_id, "yes")
                _send(
                    f"✅ *Got it!*\n"
                    f"Proceeding to apply for job `{job_id}`.\n"
                    f"You'll get a confirmation when done."
                )
                counts["yes"] += 1
                print(f"Approval YES for job: {job_id}")

            # ── NO <job_id> ────────────────────────────────────
            elif upper.startswith("NO "):
                job_id = text.split(" ", 1)[1].strip()
                set_approval_decision_by_job(job_id, "no")
                _send(f"🚫 Skipped job `{job_id}`. Moving on.")
                counts["no"] += 1
                print(f"Approval NO for job: {job_id}")

            # ── ANS <id> <answer> ──────────────────────────────
            elif upper.startswith("ANS "):
                parts = text.split(" ", 2)
                if len(parts) >= 3:
                    try:
                        qid    = int(parts[1].strip())
                        answer = parts[2].strip()
                        answer_question(qid, answer)
                        _send(
                            f"✅ *Saved!*\n"
                            f"_{answer}_\n"
                            f"Reused in all future forms automatically."
                        )
                        counts["ans"] += 1
                        print(f"Answer saved Q{qid}: {answer}")
                    except ValueError:
                        _send(
                            "⚠️ Wrong format.\n"
                            "Use: `ANS <number> <answer>`"
                        )

            # ── Unknown reply ──────────────────────────────────
            else:
                _send(
                    "🤖 *Commands I understand:*\n\n"
                    "`YES <job_id>` — approve application\n"
                    "`NO <job_id>`  — skip job\n"
                    "`ANS <id> <answer>` — answer form question"
                )

        # ✅ FIXED: Catch timeouts gracefully without breaking execution flow
        except requests.exceptions.Timeout:
            print("⚠️ WhatsApp connection timed out temporarily. Skipping cycle...")
            break
        except Exception as e:
            print(f"Reply poll error: {e}")
            break

    return counts

def test_connection() -> bool:
    result = _send(
        "🤖 *Job Agent Connected!*\n\n"
        "*Approval Mode is ON* for week 1.\n\n"
        "For each matched job I will send you details\n"
        "and ask for approval before applying.\n\n"
        "Commands:\n"
        "`YES <job_id>` — approve\n"
        "`NO <job_id>`  — skip\n"
        "`ANS <id> <answer>` — answer form questions\n\n"
        "_After week 1, set APPROVAL_MODE=False in config.py_"
    )
    print("✅ WhatsApp OK" if result else "❌ WhatsApp failed")
    return result


if __name__ == "__main__":
    test_connection()

# ── Compatibility wrappers for older scripts ─────────────────

def notify_application_sent(job_title: str, company: str, recruiter: str, apply_method: str, message: str = "") -> bool:
    """Backward-compatible notification wrapper."""
    msg = (
        f"📣 *Application Sent*\n\n"
        f"💼 *Position:* {job_title}\n"
        f"🏢 *Company:* {company}\n"
        f"👤 *Contact:* {recruiter or 'Not listed'}\n"
        f"🔧 *Method:* {apply_method}\n"
        + (f"\n{message}" if message else "")
    )
    return _send(msg)


def ask_missing_info(job_title: str, company: str, question: str, field_name: str, question_id: int) -> bool:
    return ask_for_missing_info(job_title, company, question, question_id)


def process_your_replies() -> dict:
    return receive_and_process_replies()