import time
import random
import json
import os
import hashlib
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import (
    TimeoutException, NoSuchElementException, 
    ElementClickInterceptedException
)
from dotenv import load_dotenv

from database import (
    init_database, job_already_applied, save_application,
    get_learned_answer, save_pending_question
)
from ai_matcher import (
    load_resume_data, match_job_to_resume, 
    identify_missing_fields, extract_job_details_from_post
)
from whatsapp_handler import (
    notify_application_sent, ask_missing_info
)
from email_sender import send_resume_email

load_dotenv()

# ─── CONFIGURATION ───────────────────────────────────────
LINKEDIN_EMAIL = os.getenv("YOUR_EMAIL")
LINKEDIN_PASSWORD = os.getenv("LINKEDIN_PASSWORD")  # Add to .env
RESUME_PATH = "my_resume.pdf"

# Job search settings — customize these
JOB_SEARCH_KEYWORDS = [
    "Software Engineer",
    "Backend Developer", 
    "Python Developer"
]
JOB_LOCATION = "Pakistan"  # or "Remote" or your city

# Safety: max applications per run
MAX_APPLICATIONS_PER_RUN = 10
MIN_MATCH_SCORE = 65  # Only apply if AI match score >= this

# Human-like delays (seconds) — critical for avoiding detection
MIN_DELAY = 3
MAX_DELAY = 8
# ─────────────────────────────────────────────────────────

def human_delay(min_s=None, max_s=None):
    """Random delay to simulate human behavior"""
    time.sleep(random.uniform(
        min_s or MIN_DELAY, 
        max_s or MAX_DELAY
    ))

def create_driver():
    """Create a Selenium Chrome driver"""
    options = webdriver.ChromeOptions()
    
    # Make it look less like automation
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    options.add_argument("--window-size=1366,768")
    options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    
    # Uncomment below to run without opening a browser window
    # options.add_argument("--headless")
    
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )
    
    # Hide webdriver property
    driver.execute_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    
    return driver

def login_to_linkedin(driver):
    """Log into LinkedIn"""
    print("Logging into LinkedIn...")
    driver.get("https://www.linkedin.com/login")
    human_delay(2, 4)
    
    # Enter email
    email_field = driver.find_element(By.ID, "username")
    email_field.clear()
    for char in LINKEDIN_EMAIL:
        email_field.send_keys(char)
        time.sleep(random.uniform(0.05, 0.15))  # Typing speed
    
    human_delay(0.5, 1.5)
    
    # Enter password
    password_field = driver.find_element(By.ID, "password")
    password_field.clear()
    for char in LINKEDIN_PASSWORD:
        password_field.send_keys(char)
        time.sleep(random.uniform(0.05, 0.15))
    
    human_delay(0.5, 1)
    password_field.send_keys(Keys.RETURN)
    human_delay(3, 5)
    
    # Check if login successful
    if "feed" in driver.current_url or "checkpoint" in driver.current_url:
        print("Login successful!")
        return True
    else:
        print(f"Login may have failed. Current URL: {driver.current_url}")
        # Handle CAPTCHA manually if needed
        input("If you see a CAPTCHA, solve it manually then press Enter...")
        return True

def search_jobs(driver, keywords: str, location: str) -> list:
    """Search LinkedIn jobs and return list of job URLs"""
    print(f"Searching for: {keywords} in {location}")
    
    search_url = (
        f"https://www.linkedin.com/jobs/search/"
        f"?keywords={keywords.replace(' ', '%20')}"
        f"&location={location.replace(' ', '%20')}"
        f"&f_AL=true"  # Easy Apply filter
    )
    
    driver.get(search_url)
    human_delay(3, 5)
    
    job_urls = []
    
    # Scroll to load more jobs
    for scroll in range(3):
        driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight);"
        )
        human_delay(2, 3)
    
    # Find all job cards
    try:
        job_cards = driver.find_elements(
            By.CSS_SELECTOR, 
            "a[href*='/jobs/view/']"
        )
        
        for card in job_cards:
            href = card.get_attribute("href")
            if href and "/jobs/view/" in href:
                # Clean URL
                base_url = href.split("?")[0]
                if base_url not in job_urls:
                    job_urls.append(base_url)
    
    except Exception as e:
        print(f"Error finding job cards: {e}")
    
    print(f"Found {len(job_urls)} jobs for '{keywords}'")
    return job_urls[:20]  # Limit per search

def get_job_details(driver, job_url: str) -> dict:
    """Extract details from a job posting page"""
    driver.get(job_url)
    human_delay(2, 4)
    
    details = {
        "url": job_url,
        "id": hashlib.md5(job_url.encode()).hexdigest()[:12]
    }
    
    try:
        # Job title
        title_el = driver.find_element(
            By.CSS_SELECTOR, 
            "h1.job-details-jobs-unified-top-card__job-title, h1.t-24"
        )
        details["title"] = title_el.text.strip()
    except:
        details["title"] = "Unknown Title"
    
    try:
        # Company name
        company_el = driver.find_element(
            By.CSS_SELECTOR, 
            "a.job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"
        )
        details["company"] = company_el.text.strip()
    except:
        details["company"] = "Unknown Company"
    
    try:
        # Job description
        desc_el = driver.find_element(
            By.CSS_SELECTOR, 
            "#job-details, .jobs-description__content"
        )
        details["description"] = desc_el.text[:3000]
    except:
        details["description"] = ""
    
    try:
        # Check for Easy Apply button
        easy_apply_btn = driver.find_element(
            By.CSS_SELECTOR, 
            "button[aria-label*='Easy Apply'], .jobs-apply-button--top-card"
        )
        details["has_easy_apply"] = True
    except:
        details["has_easy_apply"] = False
    
    return details

def handle_easy_apply(driver, job_details: dict, 
                       resume_data: dict) -> bool:
    """Handle LinkedIn Easy Apply process"""
    print(f"Attempting Easy Apply for {job_details['title']}")
    
    try:
        # Click Easy Apply button
        easy_apply_btn = driver.find_element(
            By.CSS_SELECTOR, 
            "button[aria-label*='Easy Apply'], .jobs-apply-button--top-card"
        )
        easy_apply_btn.click()
        human_delay(2, 3)
        
        # Go through application steps
        max_steps = 8
        
        for step in range(max_steps):
            human_delay(1, 2)
            
            # Collect all form fields on current page
            form_fields = []
            
            # Text inputs
            text_inputs = driver.find_elements(
                By.CSS_SELECTOR, 
                "input[type='text'], input[type='number'], input[type='tel']"
            )
            
            # Textareas
            textareas = driver.find_elements(By.TAG_NAME, "textarea")
            
            # Collect field labels
            all_fields = []
            for inp in text_inputs + textareas:
                try:
                    # Try to find label
                    field_id = inp.get_attribute("id")
                    label = ""
                    if field_id:
                        try:
                            label_el = driver.find_element(
                                By.CSS_SELECTOR, 
                                f"label[for='{field_id}']"
                            )
                            label = label_el.text.strip()
                        except:
                            pass
                    
                    current_value = inp.get_attribute("value") or ""
                    
                    all_fields.append({
                        "element": inp,
                        "label": label,
                        "current_value": current_value,
                        "empty": not current_value.strip()
                    })
                except:
                    pass
            
            # Get labels for AI analysis
            field_labels = [f["label"] for f in all_fields if f["empty"] and f["label"]]
            
            if field_labels:
                # Ask AI what to fill
                field_answers = identify_missing_fields(
                    field_labels, 
                    resume_data
                )
                
                for field_info in field_answers:
                    if field_info.get("needs_human") and not field_info.get("can_answer"):
                        # Check if we already know this answer
                        question_key = field_info["field_label"].lower().strip()[:100]
                        known_answer = get_learned_answer(question_key)
                        
                        if known_answer:
                            field_info["answer"] = known_answer
                            field_info["can_answer"] = True
                        else:
                            # Ask via WhatsApp and pause
                            q_id = len(all_fields) + step * 100
                            save_pending_question(
                                job_details["id"],
                                field_info["field_label"],
                                field_info["field_label"]
                            )
                            ask_missing_info(
                                job_details["title"],
                                job_details["company"],
                                field_info["field_label"],
                                field_info["field_label"],
                                q_id
                            )
                            # For now, skip this application
                            # (it will be retried after you answer)
                            print(f"Missing info requested via WhatsApp: {field_info['field_label']}")
                
                # Fill in fields where we have answers
                for field in all_fields:
                    if field["empty"] and field["label"]:
                        for answer_info in field_answers:
                            if (answer_info["field_label"] == field["label"] 
                                    and answer_info.get("can_answer") 
                                    and answer_info.get("answer")):
                                try:
                                    field["element"].clear()
                                    field["element"].send_keys(
                                        str(answer_info["answer"])
                                    )
                                    human_delay(0.3, 0.8)
                                except:
                                    pass
            
            # Try to click Next or Submit
            submitted = False
            
            # Look for Submit button first
            try:
                submit_btn = driver.find_element(
                    By.CSS_SELECTOR, 
                    "button[aria-label*='Submit application']"
                )
                submit_btn.click()
                human_delay(2, 3)
                print(f"Application submitted for {job_details['title']}!")
                submitted = True
                return True
            except NoSuchElementException:
                pass
            
            # Look for Next button
            try:
                next_btn = driver.find_element(
                    By.CSS_SELECTOR, 
                    "button[aria-label*='Continue to next step'], button[aria-label*='Next']"
                )
                next_btn.click()
                human_delay(1, 2)
            except NoSuchElementException:
                # Look for Review button
                try:
                    review_btn = driver.find_element(
                        By.CSS_SELECTOR, 
                        "button[aria-label*='Review your application']"
                    )
                    review_btn.click()
                    human_delay(1, 2)
                except:
                    print("Could not find Next/Submit button")
                    break
        
        return False
        
    except Exception as e:
        print(f"Easy Apply failed: {e}")
        return False

def process_feed_posts(driver, resume_data: dict) -> int:
    """
    Scan LinkedIn feed for job posts (not official job listings).
    Handles email applications and external links.
    """
    print("Scanning LinkedIn feed for job posts...")
    
    driver.get("https://www.linkedin.com/feed/")
    human_delay(3, 5)
    
    applied_count = 0
    
    # Scroll feed a few times to load posts
    for scroll in range(5):
        driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight);"
        )
        human_delay(2, 3)
    
    # Get all post texts
    try:
        posts = driver.find_elements(
            By.CSS_SELECTOR, 
            ".feed-shared-update-v2, .occludable-update"
        )
        
        for post in posts[:20]:  # Check first 20 posts
            try:
                post_text = post.text
                
                # Quick pre-filter: skip if no job keywords
                job_keywords = [
                    "hiring", "looking for", "position", "role", 
                    "opportunity", "job", "vacancy", "apply", "resume",
                    "CV", "candidate"
                ]
                if not any(kw.lower() in post_text.lower() for kw in job_keywords):
                    continue
                
                # AI analysis of the post
                job_info = extract_job_details_from_post(post_text)
                
                if not job_info.get("is_job_posting"):
                    continue
                
                print(f"Found job post: {job_info.get('job_title')} at {job_info.get('company_name')}")
                
                # Generate unique ID for this post
                post_id = hashlib.md5(post_text[:200].encode()).hexdigest()[:12]
                
                if job_already_applied(post_id):
                    continue
                
                # Match against resume
                match = match_job_to_resume(
                    job_info.get("job_title", ""),
                    job_info.get("job_description", ""),
                    resume_data
                )
                
                if not match.get("should_apply") or match.get("match_score", 0) < MIN_MATCH_SCORE:
                    print(f"Skipping (match score: {match.get('match_score')})")
                    continue
                
                # Determine how to apply
                method = job_info.get("application_method", "unclear")
                email = job_info.get("email_to_apply")
                link = job_info.get("external_link")
                
                success = False
                
                if email and method == "email":
                    # Send email with resume
                    success = send_resume_email(
                        to_email=email,
                        recruiter_name=job_info.get("recruiter_name"),
                        job_title=job_info.get("job_title", ""),
                        company_name=job_info.get("company_name", ""),
                        resume_path=RESUME_PATH,
                        resume_data=resume_data
                    )
                    
                    if success:
                        save_application(
                            post_id,
                            job_info.get("job_title"),
                            job_info.get("company_name"),
                            job_info.get("recruiter_name"),
                            "email",
                            "applied",
                            driver.current_url,
                            email_sent_to=email
                        )
                        notify_application_sent(
                            job_info.get("job_title", ""),
                            job_info.get("company_name", ""),
                            job_info.get("recruiter_name", ""),
                            "email",
                            f"Resume sent to: {email}"
                        )
                        applied_count += 1
                
                elif link and method == "link":
                    # Log external application (full external form automation
                    # is complex and varies per site — log it for manual followup)
                    save_application(
                        post_id,
                        job_info.get("job_title"),
                        job_info.get("company_name"),
                        job_info.get("recruiter_name"),
                        "external",
                        "applied",
                        link
                    )
                    notify_application_sent(
                        job_info.get("job_title", ""),
                        job_info.get("company_name", ""),
                        job_info.get("recruiter_name", ""),
                        "external",
                        f"External link: {link}"
                    )
                    applied_count += 1
                
                human_delay(5, 10)  # Important pause between applications
                
            except Exception as e:
                print(f"Error processing post: {e}")
                continue
    
    except Exception as e:
        print(f"Error scanning feed: {e}")
    
    return applied_count

def run_agent():
    """Main agent runner"""
    print("=" * 50)
    print("LinkedIn Job Agent Starting...")
    print("=" * 50)
    
    # Initialize
    init_database()
    resume_data = load_resume_data()
    print(f"Loaded resume for: {resume_data.get('full_name')}")
    
    driver = create_driver()
    total_applied = 0
    
    try:
        # Login
        login_to_linkedin(driver)
        human_delay(3, 5)
        
        # PART 1: Scan job listings (Easy Apply)
        for keywords in JOB_SEARCH_KEYWORDS:
            if total_applied >= MAX_APPLICATIONS_PER_RUN:
                print(f"Reached max applications limit: {MAX_APPLICATIONS_PER_RUN}")
                break
            
            job_urls = search_jobs(driver, keywords, JOB_LOCATION)
            
            for job_url in job_urls:
                if total_applied >= MAX_APPLICATIONS_PER_RUN:
                    break
                
                # Get job details
                job_details = get_job_details(driver, job_url)
                job_id = job_details["id"]
                
                # Skip if already applied
                if job_already_applied(job_id):
                    print(f"Already applied to: {job_details['title']}")
                    continue
                
                # AI matching
                match = match_job_to_resume(
                    job_details["title"],
                    job_details["description"],
                    resume_data
                )
                
                print(f"Match score for {job_details['title']}: {match.get('match_score')}%")
                
                if not match.get("should_apply"):
                    print(f"Skipping — below threshold")
                    continue
                
                # Apply
                if job_details.get("has_easy_apply"):
                    success = handle_easy_apply(driver, job_details, resume_data)
                    
                    if success:
                        save_application(
                            job_id,
                            job_details["title"],
                            job_details["company"],
                            None,
                            "easy_apply",
                            "applied",
                            job_url
                        )
                        notify_application_sent(
                            job_details["title"],
                            job_details["company"],
                            "Not available",
                            "easy_apply"
                        )
                        total_applied += 1
                        print(f"Applied! Total today: {total_applied}")
                
                # Pause between applications — critical
                human_delay(15, 30)
        
        # PART 2: Scan feed posts
        feed_applied = process_feed_posts(driver, resume_data)
        total_applied += feed_applied
        
    except Exception as e:
        print(f"Agent error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()
        print(f"\nAgent finished. Total applications this run: {total_applied}")

if __name__ == "__main__":
    run_agent()