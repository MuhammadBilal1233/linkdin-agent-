"""
AI Engine — google-genai SDK (v1 API).

FIXES IN THIS VERSION:

FIX 1 — Score: 0% for all Remote jobs
  Root cause: is_location_allowed() only checked job_location text extracted
  from the LinkedIn page. But for globally-remote jobs, LinkedIn shows the
  location as "Europe", "Worldwide", "Belgium", or sometimes nothing at all
  — none of which match our ALLOWED_LOCATIONS list.
  Fix: match_job_to_resume() now accepts search_location parameter.
  When the agent searched for "Remote", that context is passed in and
  is_location_allowed() returns True immediately for any "Remote" search.

FIX 2 — Gemini 429 daily quota exhausted
  Root cause: 8 keywords × 3 locations × 15 jobs = 360 AI calls per run.
  Free tier limit is 1500/day but also 30 RPM. When daily limit is hit,
  the retry loop just waits 65s and tries again — which also fails.
  Fix: detect daily quota exhaustion (limit: 0 in the error) and switch
  immediately to keyword-only fallback for that run instead of retrying
  endlessly. Print one clear warning, stop wasting time.

FIX 3 — Bad fallback scores (NodeJS/Ruby jobs scoring 30%)
  Root cause: keyword_fallback matched generic skills like "javascript",
  "git", "sql", "html" which appear in nearly every job description.
  'Senior NodeJS Developer' → matched 'javascript' → score 35% → printed.
  Fix: fallback now requires at least one PRIMARY .NET/Angular skill to match.
  Generic skills (javascript, git, html, css, sql, python) alone are not enough.
  Only .net, c#, angular, asp.net, entity framework, etc. count as primary.
"""

from __future__ import annotations

import html
import json
import os
import time
import threading
from collections import deque
from typing import Any

from google import genai
from dotenv import load_dotenv

from config import (
    ALLOWED_LOCATIONS,
    MIN_EXPERIENCE_RATIO,
    MIN_MATCH_SCORE,
    MIN_MUST_HAVE_SKILLS_COVERAGE,
    SPARSE_POST_THRESHOLD,
)

load_dotenv()

_api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
_client  = genai.Client(api_key=_api_key)

MODEL_FAST  = "gemini-2.0-flash"          # primary model for all calls
MODEL_SMART = "gemini-2.0-flash"          # same model, kept for cover letters

# FIX 2: track whether daily quota is hit so we stop retrying
_daily_quota_exhausted = False

# Primary skills — at least one MUST match in keyword fallback
# Generic skills like javascript/git/html alone are not enough
_PRIMARY_SKILLS = {
    ".net", ".net core", "c#", "asp.net", "asp.net web api",
    "entity framework", "entity framework core", "blazor", "wpf",
    "angular", "rxjs",
}

# ── Rate limiter ──────────────────────────────────────────────

_rate_lock = threading.Lock()
_call_log: dict[str, deque] = {
    MODEL_FAST:  deque(),
    MODEL_SMART: deque(),
}
_RPM_LIMITS = {
    MODEL_FAST:  28,
    MODEL_SMART: 28,  # same model as MODEL_FAST
}


def reset_quota_flag():
    """Reset the daily quota exhausted flag. Call at the start of each agent run."""
    global _daily_quota_exhausted
    _daily_quota_exhausted = False


def _rate_limit(model: str):
    """Block if approaching per-minute quota limit."""
    limit = _RPM_LIMITS.get(model, 28)
    log   = _call_log.setdefault(model, deque())
    with _rate_lock:
        now = time.time()
        while log and now - log[0] > 60:
            log.popleft()
        if len(log) >= limit:
            wait = 62 - (now - log[0])
            if wait > 0:
                print(f"   ⏳ Rate limit pause {wait:.0f}s...")
                time.sleep(wait)
            now = time.time()
            while log and now - log[0] > 60:
                log.popleft()
        log.append(time.time())


# ── Core API call ─────────────────────────────────────────────

def _call(prompt: str, model: str = MODEL_FAST) -> str:
    """
    Call Gemini with rate limiting.
    FIX 2: detects daily quota exhaustion and sets flag to stop retrying.
    """
    global _daily_quota_exhausted

    if _daily_quota_exhausted:
        raise RuntimeError("DAILY_QUOTA_EXHAUSTED")

    _rate_limit(model)

    try:
        response = _client.models.generate_content(model=model, contents=prompt)
        return (response.text or "").strip()

    except Exception as e:
        err = str(e)

        if "429" in err or "RESOURCE_EXHAUSTED" in err:
            # Detect daily quota exhaustion from the new google-genai SDK error format
            is_daily = (
                "PerDay" in err
                or "limit: 0" in err
                or "GenerateRequestsPerDay" in err
                or "FreeTier" in err
                or "free_tier" in err.lower()
            )
            if is_daily:
                _daily_quota_exhausted = True
                print(
                    "\n⚠️  GEMINI DAILY QUOTA EXHAUSTED\n"
                    "   Free-tier quota (requests/day) has been used up.\n"
                    "   AI matching paused for this run — using keyword fallback.\n"
                    "   Quota resets at midnight Pacific time.\n"
                    "   To fix: get a paid Gemini API key at https://aistudio.google.com\n"
                )
                raise RuntimeError("DAILY_QUOTA_EXHAUSTED")

            # Per-minute rate limit — extract retry delay from error and wait
            wait = 65
            try:
                import re as _re
                m = _re.search(r'retryDelay.*?(\d+)s', err)
                if m:
                    wait = int(m.group(1)) + 5
                elif "seconds:" in err:
                    wait = int(err.split("seconds:")[1].split()[0].strip()) + 5
            except Exception:
                pass
            print(f"   ⏳ Gemini rate limit — waiting {wait}s...")
            time.sleep(wait)
            # Note: do NOT call _rate_limit again — the first call already
            # logged this request. Double-counting would inflate the limiter.
            try:
                response = _client.models.generate_content(model=model, contents=prompt)
                return (response.text or "").strip()
            except Exception as e2:
                err2 = str(e2)
                if ("429" in err2 or "RESOURCE_EXHAUSTED" in err2) and (
                    "PerDay" in err2 or "limit: 0" in err2
                    or "GenerateRequestsPerDay" in err2
                    or "FreeTier" in err2 or "free_tier" in err2.lower()
                ):
                    _daily_quota_exhausted = True
                    print("\n⚠️  GEMINI DAILY QUOTA EXHAUSTED (on retry)")
                    raise RuntimeError("DAILY_QUOTA_EXHAUSTED")
                raise e2

        raise


def _call_with_fallback(prompt: str,
                         primary: str = MODEL_FAST,
                         fallback: str = MODEL_SMART) -> str:
    try:
        return _call(prompt, primary)
    except Exception as e1:
        if "DAILY_QUOTA_EXHAUSTED" in str(e1):
            raise
        try:
            return _call(prompt, fallback)
        except Exception as e2:
            raise e2


# ── JSON helpers ──────────────────────────────────────────────

def _clean_json(text: str) -> str:
    raw = (text or "").strip()
    if "```json" in raw:
        raw = raw.split("```json", 1)[1].split("```", 1)[0]
    elif "```" in raw:
        raw = raw.split("```", 1)[1].split("```", 1)[0]
    return raw.strip()


def _parse_json(text: str, default: Any) -> Any:
    try:
        return json.loads(_clean_json(text))
    except Exception:
        return default


def _safe_list(v: Any) -> list:
    if isinstance(v, list):
        return v
    if v is None:
        return []
    return [v]


# ── Location check ────────────────────────────────────────────

def is_location_allowed(job_location: str,
                         job_description: str = "",
                         search_location: str = "") -> bool:
    """
    FIX 1: Added search_location parameter.

    When the agent searched LinkedIn for 'Remote', every result IS remote
    by definition — we trust the search parameter rather than re-checking
    the extracted job_location field (which may show country/city names
    for globally-remote roles, not the word 'remote' itself).

    Priority:
    1. If search_location is 'Remote' → always True
    2. If search_location is 'Pakistan'/'Lahore' → always True
    3. Otherwise check job_location + description text
    """
    if search_location:
        sl = search_location.lower()
        if sl in ("remote",):
            return True
        if any(x in sl for x in ("pakistan", "lahore", "karachi",
                                  "islamabad", "rawalpindi", "faisalabad")):
            return True

    combined = f"{job_location or ''} {job_description or ''}".lower()
    if not combined.strip():
        return True   # no info → benefit of doubt

    return any(loc.lower() in combined for loc in ALLOWED_LOCATIONS)


# ── Experience summary ────────────────────────────────────────

def _summarize_experience(resume_data: dict) -> str:
    jobs = resume_data.get("work_experience") or []
    if not jobs:
        return "  - No work experience listed"
    lines = []
    for job in jobs[:4]:
        lines.append(
            f"  - {job.get('title','')} at {job.get('company','')} "
            f"({job.get('start_date','')} – {job.get('end_date','Present')}): "
            f"{(job.get('description','') or '')[:160]}"
        )
    return "\n".join(lines)


# ── Keyword fallback ──────────────────────────────────────────

def _keyword_fallback(job_title: str, job_description: str,
                       resume_data: dict, job_location: str,
                       search_location: str = "") -> dict:
    """
    FIX 3: Now requires at least one PRIMARY skill (.net/c#/angular)
    to match before giving a positive score.
    Generic skills (javascript, git, html, sql) alone are not enough.
    This prevents NodeJS/Ruby/Java jobs from scoring 30%.
    """
    all_skills = set()
    for key in ("skills", "programming_languages", "frameworks",
                "tools", "databases", "cloud_platforms"):
        all_skills.update(s.lower() for s in _safe_list(resume_data.get(key, [])))

    text = f"{job_title} {job_description}".lower()

    # All matched skills
    matched_all = sorted(s for s in all_skills if s and len(s) > 2 and s in text)

    # Primary skills matched
    matched_primary = [s for s in matched_all if s in _PRIMARY_SKILLS]

    loc_ok = is_location_allowed(job_location, job_description, search_location)

    # FIX: only give positive score if at least one PRIMARY skill matches
    if matched_primary:
        score = min(70, 40 + len(matched_primary) * 10 + len(matched_all) * 2)
        should = loc_ok and score >= MIN_MATCH_SCORE
    else:
        # No primary skill match — reject regardless of generic skill overlap
        score = 20
        should = False

    return {
        "match_score":      score if loc_ok else 0,
        "should_apply":     should,
        "is_sparse_post":   len((job_description or "").strip()) < SPARSE_POST_THRESHOLD,
        "location_allowed": loc_ok,
        "location": {
            "job_location_text": job_location or "",
            "is_remote":   "remote" in text or search_location.lower() == "remote",
            "is_pakistan": any(x in text for x in ["pakistan", "lahore"]),
            "location_ok": loc_ok,
        },
        "experience": {
            "required_years":    None,
            "candidate_years":   resume_data.get("years_of_experience", 0),
            "ratio":             1.0,
            "meets_requirement": True,
        },
        "skills": {
            "must_have":            [],
            "candidate_has":        matched_primary or matched_all[:3],
            "candidate_missing":    [],
            "coverage_percent":     80 if matched_primary else 0,
            "nice_to_have_matched": [],
        },
        "seniority":  {"job_level": "any", "candidate_level": "mid", "level_match": True},
        "education":  {"required": "none", "candidate_has": "", "meets_requirement": True},
        "reject_reason":    None if should else ("no_primary_skill_match" if not matched_primary else "location"),
        "reason":     (
            f"Keyword match on primary skills: {', '.join(matched_primary[:3])}"
            if matched_primary else
            "No primary .NET/C#/Angular skill found in job"
        ),
        "strengths":        matched_primary,
        "weaknesses":       [],
        "matching_skills":  matched_primary or [],
        "missing_skills":   [],
    }


# ── Main matching ─────────────────────────────────────────────

def match_job_to_resume(job_title: str,
                         job_description: str,
                         resume_data: dict,
                         job_location: str = "",
                         search_location: str = "") -> dict:
    """
    Match a job to the candidate's resume.

    FIX 1: search_location parameter added.
    When called from scan_job_listings() with search_location='Remote',
    is_location_allowed() returns True immediately — no more Score: 0%.

    Step 1: Location check (free, no API call)
    Step 2: Short post → sparse matching
    Step 3: Full AI comparison
    """
    # Step 1 — location gate
    loc_ok = is_location_allowed(job_location, job_description, search_location)
    if not loc_ok:
        return {
            "match_score":      0,
            "should_apply":     False,
            "reject_reason":    "location_mismatch",
            "reason":           f"'{job_location}' is not Pakistan or Remote",
            "location_allowed": False,
            "matching_skills":  [],
            "missing_skills":   [],
        }

    # Step 2 — sparse post
    if len((job_description or "").strip()) < SPARSE_POST_THRESHOLD:
        return _match_sparse_post(
            job_title, job_description, resume_data,
            job_location, search_location
        )

    # Step 3 — full AI match
    fallback = _keyword_fallback(
        job_title, job_description, resume_data, job_location, search_location
    )

    if _daily_quota_exhausted:
        return {**fallback, "reason": fallback["reason"] + " [AI quota exhausted — keyword only]"}

    candidate_profile = f"""CANDIDATE:
- Name: {resume_data.get('full_name')}
- Title: {resume_data.get('current_job_title')}
- Experience: {resume_data.get('years_of_experience')} years
- Primary Stack: .NET Core, C#, Angular, SQL Server, Azure
- All Skills: {', '.join(_safe_list(resume_data.get('skills', []))[:20])}
- Languages: {', '.join(_safe_list(resume_data.get('programming_languages', [])))}
- Frameworks: {', '.join(_safe_list(resume_data.get('frameworks', [])))}
- Databases: {', '.join(_safe_list(resume_data.get('databases', [])))}
- Cloud: {', '.join(_safe_list(resume_data.get('cloud_platforms', [])))}
- Tools: {', '.join(_safe_list(resume_data.get('tools', [])))}
- Work History:
{_summarize_experience(resume_data)}"""

    prompt = f"""You are a strict job screener. Evaluate fit for this candidate.

{candidate_profile}

JOB:
Title: {job_title}
Location: {job_location}
Search context: Found in a '{search_location}' search on LinkedIn
Description: {(job_description or '')[:3000]}

STRICT RULES:
- If job primarily requires Ruby, Java, PHP, Node.js, React, Laravel, Vue.js,
  Go, Kotlin, Swift, or Python — set match_score < 40 and should_apply=false.
- Candidate's PRIMARY stack is .NET Core, C#, Angular, SQL Server, Azure.
- Only set should_apply=true when candidate has the CORE required technology.
- Location is OK because this was found in a '{search_location}' LinkedIn search.

Return ONLY valid JSON:
{{
  "match_score": <0-100>,
  "should_apply": <true/false>,
  "is_sparse_post": false,
  "location": {{
    "job_location_text": "{job_location}",
    "is_remote": <true/false>,
    "is_pakistan": <true/false>,
    "location_ok": true
  }},
  "experience": {{
    "required_years": <number or null>,
    "candidate_years": {resume_data.get('years_of_experience', 0)},
    "ratio": <float>,
    "meets_requirement": <true/false>
  }},
  "skills": {{
    "must_have": ["skill"],
    "candidate_has": ["skill"],
    "candidate_missing": ["skill"],
    "coverage_percent": <0-100>,
    "nice_to_have_matched": []
  }},
  "seniority": {{
    "job_level": "junior/mid/senior/lead/any",
    "candidate_level": "mid",
    "level_match": <true/false>
  }},
  "education": {{
    "required": "degree/none",
    "candidate_has": "B.Sc Computer Science UET 3.63 GPA",
    "meets_requirement": true
  }},
  "reject_reason": null,
  "reason": "<one clear sentence>",
  "strengths": ["skill"],
  "weaknesses": ["skill"]
}}

SCORING: 85-100=excellent .NET match, 70-84=good, 65-69=borderline, <65=reject"""

    try:
        text   = _call_with_fallback(prompt)
        result = _parse_json(text, {})
        if not isinstance(result, dict) or not result:
            return {**fallback, "reason": "AI empty response"}

        merged = {**fallback, **result}
        merged.setdefault("location",   fallback["location"])
        merged.setdefault("experience", fallback["experience"])
        merged.setdefault("skills",     fallback["skills"])

        score    = merged.get("match_score", 0)
        exp      = merged.get("experience", {}) or {}
        skills_d = merged.get("skills", {}) or {}

        exp_ratio = exp.get("ratio", 1.0) or 1.0
        if exp_ratio < MIN_EXPERIENCE_RATIO and exp.get("required_years"):
            merged["should_apply"]  = False
            merged["reject_reason"] = "experience_gap"
            merged["reason"] = (
                f"Requires {exp.get('required_years')} yrs, "
                f"candidate has {exp.get('candidate_years')} "
                f"(ratio {exp_ratio:.1f})"
            )

        coverage = skills_d.get("coverage_percent", 100) or 0
        if coverage < (MIN_MUST_HAVE_SKILLS_COVERAGE * 100):
            merged["should_apply"]  = False
            merged["reject_reason"] = "missing_skills"
            merged["reason"] = (
                f"Only {coverage}% required skills present. "
                f"Missing: {', '.join(_safe_list(skills_d.get('candidate_missing', []))[:3])}"
            )

        if score < MIN_MATCH_SCORE:
            merged["should_apply"] = False

        merged["location_allowed"]  = True
        merged["matching_skills"]   = _safe_list(skills_d.get("candidate_has", []))
        merged["missing_skills"]    = _safe_list(skills_d.get("candidate_missing", []))
        return merged

    except Exception as e:
        if "DAILY_QUOTA_EXHAUSTED" in str(e):
            return {**fallback, "reason": fallback["reason"] + " [AI quota exhausted]"}
        print(f"   Match error: {str(e)[:80]}")
        return {**fallback, "reason": f"AI error: {str(e)[:60]}"}


# ── Sparse post matching ──────────────────────────────────────

def _match_sparse_post(job_title: str, job_description: str,
                        resume_data: dict, job_location: str,
                        search_location: str = "") -> dict:
    """Lighter matching for short posts like '.NET dev needed 3-5 yrs'."""
    candidate_years = resume_data.get("years_of_experience", 0)
    all_skills = (
        [s.lower() for s in _safe_list(resume_data.get("skills", []))] +
        [s.lower() for s in _safe_list(resume_data.get("programming_languages", []))] +
        [s.lower() for s in _safe_list(resume_data.get("frameworks", []))] +
        [s.lower() for s in _safe_list(resume_data.get("tools", []))]
    )
    combined = f"{job_title} {job_description or ''}".lower()

    prompt = f"""Short LinkedIn job post — extract info and assess fit.

POST: "{combined[:500]}"

CANDIDATE:
- Years of experience: {candidate_years}
- Primary skills: .NET Core, C#, Angular, SQL Server, Azure
- All skills: {', '.join(all_skills[:25])}

Return ONLY this JSON:
{{
  "core_technologies": ["tech1"],
  "required_years_min": <number or null>,
  "candidate_has_core_tech": <true/false>,
  "which_techs_matched": ["tech"],
  "which_techs_missing": ["tech"],
  "experience_ok": <true/false>,
  "reason": "<one sentence>"
}}
candidate_has_core_tech=true only if .NET/C#/Angular/ASP.NET is the primary required skill."""

    base = {
        "is_sparse_post":   True,
        "location_allowed": True,
        "experience": {
            "required_years": None, "candidate_years": candidate_years,
            "ratio": 1.0, "meets_requirement": True,
        },
        "skills": {
            "must_have": [], "candidate_has": [], "candidate_missing": [],
            "coverage_percent": 0, "nice_to_have_matched": [],
        },
        "seniority":  {"job_level": "any", "candidate_level": "mid", "level_match": True},
        "education":  {"required": "none", "candidate_has": "", "meets_requirement": True},
        "matching_skills": [],
        "missing_skills":  [],
    }

    # Keyword fallback for sparse post when AI unavailable
    def _sparse_keyword_fallback():
        primary_matched = [s for s in _PRIMARY_SKILLS if s in combined]
        has_tech = bool(primary_matched)
        base["skills"]["candidate_has"]    = primary_matched
        base["skills"]["coverage_percent"] = 100 if has_tech else 0
        base["matching_skills"] = primary_matched
        if has_tech:
            base.update({"match_score": 65, "should_apply": True,
                         "reject_reason": None,
                         "reason": f"Sparse post — keyword: {', '.join(primary_matched)}",
                         "strengths": primary_matched, "weaknesses": []})
        else:
            base.update({"match_score": 20, "should_apply": False,
                         "reject_reason": "missing_core_technology",
                         "reason": "Sparse post — no .NET/C#/Angular keyword found",
                         "strengths": [], "weaknesses": ["Need .NET/C#/Angular"]})
        return base

    if _daily_quota_exhausted:
        return _sparse_keyword_fallback()

    try:
        text   = _call(prompt, MODEL_FAST)
        parsed = _parse_json(text, {})
        if not isinstance(parsed, dict):
            parsed = {}

        has_tech   = parsed.get("candidate_has_core_tech", False)
        exp_ok     = parsed.get("experience_ok", True)
        matched    = _safe_list(parsed.get("which_techs_matched", []))
        missing    = _safe_list(parsed.get("which_techs_missing", []))
        core       = _safe_list(parsed.get("core_technologies", []))
        years_min  = parsed.get("required_years_min")

        base["skills"].update({
            "must_have": core, "candidate_has": matched,
            "candidate_missing": missing,
            "coverage_percent": 100 if has_tech else 0,
        })
        base["experience"]["required_years"]    = years_min
        base["experience"]["meets_requirement"] = exp_ok
        base["matching_skills"] = matched
        base["missing_skills"]  = missing

        if years_min and years_min > 0:
            base["experience"]["ratio"] = round(candidate_years / years_min, 2)

        if has_tech and exp_ok:
            base.update({"match_score": 70, "should_apply": True,
                         "reject_reason": None,
                         "reason": f"Sparse — has core tech ({', '.join(matched) or 'matched'}) and meets exp.",
                         "strengths": matched, "weaknesses": missing})
        elif not has_tech:
            base.update({"match_score": 20, "should_apply": False,
                         "reject_reason": "missing_core_technology",
                         "reason": f"Core tech not in skills: {', '.join(missing)}",
                         "strengths": [], "weaknesses": missing})
        else:
            base.update({"match_score": 40, "should_apply": False,
                         "reject_reason": "experience_gap",
                         "reason": f"Has tech but below minimum ({years_min} yrs)",
                         "strengths": matched, "weaknesses": [f"Need {years_min}+ yrs"]})
        return base

    except Exception as e:
        if "DAILY_QUOTA_EXHAUSTED" in str(e):
            return _sparse_keyword_fallback()
        print(f"   Sparse match error: {str(e)[:80]}")
        return _sparse_keyword_fallback()


# ── Job post extraction ───────────────────────────────────────

def extract_job_details_from_post(post_text: str) -> dict:
    """Extract structured job info from a LinkedIn feed post."""
    fallback = {
        "is_job_posting": True, "is_job_post": True,
        "job_title": None, "company_name": None, "recruiter_name": None,
        "poster_name": None, "email_to_apply": None, "external_link": None,
        "location": None, "job_description": (post_text or "")[:400],
        "application_method": "unclear",
    }
    if _daily_quota_exhausted:
        return fallback

    prompt = f"""Analyze this LinkedIn post. Is someone actively recruiting?

POST:
{(post_text or '')[:2500]}

Return ONLY this JSON:
{{
  "is_job_posting": true/false,
  "job_title": "title or null",
  "company_name": "company or null",
  "recruiter_name": "poster name or null",
  "email_to_apply": "email or null",
  "external_link": "https://... or null",
  "location": "city or remote or null",
  "job_description": "brief description or null",
  "application_method": "email/link/direct/unclear"
}}"""

    try:
        text   = _call(prompt, MODEL_FAST)
        parsed = _parse_json(text, {})
        if not isinstance(parsed, dict):
            return fallback
        result = {**fallback, **parsed}
        result["is_job_post"]   = result.get("is_job_posting", True)
        result["poster_name"]   = result.get("recruiter_name") or result.get("poster_name")
        return result
    except Exception:
        return fallback


extract_job_from_post = extract_job_details_from_post


# ── Form fields ───────────────────────────────────────────────

def identify_missing_fields(field_labels: list, resume_data: dict,
                              known_answers: dict | None = None) -> list:
    """Identify which form fields can be auto-filled from resume."""
    known_answers = known_answers or {}

    if _daily_quota_exhausted:
        return [{"field_label": lbl, "can_answer": bool(known_answers.get(lbl)),
                 "answer": known_answers.get(lbl), "needs_human": not bool(known_answers.get(lbl))}
                for lbl in field_labels]

    prompt = f"""Job application form fields: {json.dumps(field_labels)}
Resume: {json.dumps(resume_data, indent=2)[:2500]}

Return ONLY JSON array:
[
  {{"field_label": "First Name", "can_answer": true, "answer": "Muhammad Bilal", "needs_human": false}},
  {{"field_label": "Expected Salary", "can_answer": false, "answer": null, "needs_human": true}}
]
Standard fields (name, email, phone, education, experience) = answer from resume."""

    try:
        text   = _call(prompt, MODEL_FAST)
        parsed = _parse_json(text, [])
        if not isinstance(parsed, list):
            parsed = []
    except Exception:
        parsed = []

    result = []
    for label in field_labels:
        saved = known_answers.get(label) or known_answers.get(label.lower())
        item  = next((x for x in parsed
                      if str(x.get("field_label", "")).strip().lower() == label.lower()), None)
        if saved:
            result.append({"field_label": label, "can_answer": True,
                           "answer": saved, "needs_human": False})
        elif item:
            result.append({"field_label": label,
                           "can_answer": bool(item.get("can_answer", False)),
                           "answer": item.get("answer"),
                           "needs_human": bool(item.get("needs_human", not item.get("can_answer")))})
        else:
            result.append({"field_label": label, "can_answer": False,
                           "answer": None, "needs_human": True})
    return result


analyze_form_fields = identify_missing_fields


# ── Cover letter ──────────────────────────────────────────────

def generate_cover_letter(job_title: str, company_name: str,
                           job_description: str, resume_data: dict) -> str:
    skills  = ", ".join(_safe_list(resume_data.get("skills", []))[:8])
    summary = (resume_data.get("professional_summary") or "")[:300]
    fallback = (
        f"I am writing to express my strong interest in the {job_title} "
        f"position at {company_name}.\n\n"
        f"With {resume_data.get('years_of_experience', 4)} years of experience as a "
        f"{resume_data.get('current_job_title', 'Software Engineer')}, "
        f"I bring expertise in {skills}.\n\n"
        f"I would welcome the opportunity to discuss how my background aligns with "
        f"your team's needs. Please find my resume attached."
    )
    if _daily_quota_exhausted:
        return fallback

    prompt = f"""Write a professional job application email body. 3 paragraphs, 180-230 words. No markdown.

Candidate: {resume_data.get('full_name')} | {resume_data.get('current_job_title')} | {resume_data.get('years_of_experience')} yrs
Skills: {skills}
Summary: {summary}
Job: {job_title} at {company_name}
Description: {(job_description or '')[:1200]}"""

    try:
        text = _call(prompt, MODEL_SMART)
        return text if text else fallback
    except Exception:
        return fallback


# ── HTML shortlist ────────────────────────────────────────────

def generate_shortlist_html(shortlist: list, resume_data: dict) -> str:
    name = html.escape(resume_data.get("full_name") or "Candidate")
    rows = []
    for item in shortlist:
        title    = html.escape(str(item.get("title") or item.get("job_title") or ""))
        company  = html.escape(str(item.get("company") or item.get("company_name") or ""))
        location = html.escape(str(item.get("location") or ""))
        score    = item.get("match_score", 0)
        url      = html.escape(str(item.get("url") or "#"))
        reason   = html.escape(str(item.get("reason") or ""))
        matched  = ", ".join(_safe_list(item.get("matching_skills", []))[:5])
        color    = "#22c55e" if score >= 80 else "#f59e0b" if score >= 65 else "#ef4444"
        rows.append(f"""
<div style="border:1px solid #dbeafe;border-radius:12px;padding:16px;margin:10px 0;background:white;">
  <div style="font-size:17px;font-weight:700;color:#1e3a5f;">{title}</div>
  <div style="color:#475569;margin-top:4px;">{company} · {location}</div>
  <div style="margin-top:8px;">
    <span style="background:{color};color:white;padding:3px 12px;border-radius:20px;font-weight:700;">
      {score}% match
    </span>
  </div>
  <div style="margin-top:6px;color:#475569;font-size:14px;">{reason}</div>
  {f'<div style="margin-top:4px;color:#16a34a;font-size:13px;">✓ {matched}</div>' if matched else ''}
  <div style="margin-top:10px;">
    <a href="{url}" target="_blank"
       style="background:#2563eb;color:white;padding:8px 18px;border-radius:6px;
              text-decoration:none;font-weight:600;">Open on LinkedIn →</a>
  </div>
</div>""")

    if not rows:
        rows.append("<p style='color:#6b7280;'>No matching jobs found this run.</p>")

    return f"""<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Shortlist — {name}</title>
<style>body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
background:#f1f5f9;margin:0;padding:24px;}}
.wrap{{max-width:860px;margin:0 auto;}}
.note{{background:#fef3c7;border:1px solid #fbbf24;border-radius:8px;
padding:12px 16px;margin-bottom:16px;font-size:14px;color:#92400e;}}</style>
</head>
<body><div class="wrap">
  <h1>📋 Easy Apply Shortlist — {name}</h1>
  <p style="color:#6b7280;margin-bottom:16px;">{len(shortlist)} matched jobs · Pakistan/Remote only</p>
  <div class="note">⚠️ These require <strong>your manual Easy Apply</strong> on LinkedIn.<br>
  Email and external form jobs are handled <strong>automatically</strong>.</div>
  {''.join(rows)}
</div></body></html>"""
