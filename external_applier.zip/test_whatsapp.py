import requests

# 1. Your exact instance ID
id_instance = "7107641720"

# 2. Go to your Green-API dashboard, copy your long apiTokenInstance, and paste it right here inside the quotes:
token = "2f1324484ce54caaa90fc0f488adaa3c2050ca0f92a347428c"

# The script hooks straight into your dedicated cluster endpoint layout
url = f"https://7107.api.greenapi.com/waInstance{id_instance}/receiveNotification/{token}"

print(f"📡 Testing connection to: {url}")
try:
    response = requests.get(url, timeout=15)
    print(f"Status Code: {response.status_code}")
    print(f"Response Body: {response.text}")
    
    if response.status_code == 200:
        print("🎉 Success! Your connection to Green-API is 100% functional!")
    elif response.status_code == 401 or response.status_code == 403:
        print("❌ Authorization Failed: Double check that the token string pasted inside the quotes matches your dashboard perfectly.")
except Exception as e:
    print(f"❌ Connection failed: {e}")