"""
Main orchestrator — updated with:
  1. Approval mode (WhatsApp YES/NO before applying)
  2. CureMD / blocked company filter
  3. Detailed application log after each apply
  4. Random gap between applications
"""

import os
import time
import random
import subprocess
import webbrowser
from datetime import datetime
from dotenv import load_dotenv

from config import (
    APPROVAL_MODE,
    APPROVAL_TIMEOUT_SECONDS,
    MIN_GAP_BETWEEN_APPLIES_SEC,
    MAX_GAP_BETWEEN_APPLIES_SEC,
    EASY_APPLY_SHORTLIST_SIZE,
    MAX_APPLICATIONS_PER_RUN,
    SHORTLIST_PATH,
    APPLY_VIA_EMAIL,
    APPLY_VIA_EXTERNAL_FORMS,
)
from resume_processor import load_resume_data
from database import (
    init_database,
    is_company_blocked,
    mark_applied,
    mark_skipped,
    add_to_approval_queue,
    get_approval_decision,
    expire_old_approvals,
    log_application,
)
from linkedin_reader import (
    create_driver, login,
    scan_job_listings, scan_feed_posts,
)
from email_applier import send_resume_email
from external_applier import apply_external
from whatsapp_handler import (
    send_approval_request,
    notify_approval_timeout,
    notify_company_blocked,
    notify_shortlist_ready,
    notify_daily_summary,
    notify_external_failed,
    receive_and_process_replies,
)
from ai_engine import generate_shortlist_html, reset_quota_flag

load_dotenv()


def _apply_gap():
    """Wait a random amount of time between applications"""
    gap = random.randint(
        MIN_GAP_BETWEEN_APPLIES_SEC,
        MAX_GAP_BETWEEN_APPLIES_SEC
    )
    print(
        f"⏳ Waiting {gap // 60}m {gap % 60}s before next application..."
    )
    time.sleep(gap)


def _wait_for_approval(job_id: str,
                        timeout_sec: int) -> str:
    """
    Poll database for a YES/NO decision on this job.
    Checks every 30 seconds until timeout.
    Returns: 'yes', 'no', or 'timeout'
    """
    waited = 0
    interval = 30  # Check every 30 seconds

    print(f"   ⏳ Waiting for your WhatsApp approval (job {job_id})...")

    while waited < timeout_sec:
        # Also process any incoming replies each poll
        receive_and_process_replies()

        decision = get_approval_decision(job_id)
        if decision in ("yes", "no"):
            return decision

        time.sleep(interval)
        waited += interval
        if waited % 300 == 0:  # Log every 5 minutes
            print(
                f"   Still waiting... ({waited // 60}m elapsed)"
            )

    return "timeout"


def _execute_application(post: dict,
                          resume_data: dict,
                          approved_by_user: bool) -> bool:
    """
    Perform the actual application (email or external).
    Logs result to database.
    Returns True if application was sent successfully.
    """
    title     = post.get("job_title",    "Position")
    company   = post.get("company_name", "Company")
    recruiter = post.get("poster_name",  "")
    location  = post.get("location",     "")
    email     = post.get("email_to_apply")
    link      = post.get("external_link")
    method    = post.get("apply_method", "unclear")
    post_id   = post.get("post_id", "")
    desc      = post.get("job_description", "")
    match_result = post.get("match_result") or post

    score     = match_result.get("match_score", 0)
    matching  = (
        match_result.get("skills", {}).get("candidate_has", [])
    )
    missing   = (
        match_result.get("skills", {}).get("candidate_missing", [])
    )

    # ── Email application ──────────────────────────────────────
    if APPLY_VIA_EMAIL and email and method == "email":
        print(f"   📧 Emailing → {email}")
        ok = send_resume_email(
            to_email=email,
            recruiter_name=recruiter,
            job_title=title,
            company_name=company,
            job_description=desc,
            resume_data=resume_data,
            match_result=match_result,
            approved_by_user=approved_by_user,
        )
        log_application(
            job_id=post_id, title=title, company=company,
            location=location, recruiter=recruiter,
            method="email", target=email,
            match_score=score,
            matching_skills=matching,
            missing_skills=missing,
            cover_letter="",  # stored in email_applier
            status="sent" if ok else "failed",
            fail_reason=None if ok else "smtp_error",
            approved_by_user=approved_by_user,
        )
        if ok:
            mark_applied(post_id)
        return ok

    # ── External form application ──────────────────────────────
    elif APPLY_VIA_EXTERNAL_FORMS and link:
        print(f"   🔗 External form → {link}")
        result = apply_external(
            url=link,
            job_title=title,
            company=company,
            job_id=post_id,
            resume_data=resume_data,
            match_result=match_result,
            approved_by_user=approved_by_user,
        )
        log_application(
            job_id=post_id, title=title, company=company,
            location=location, recruiter=recruiter,
            method="external", target=link,
            match_score=score,
            matching_skills=matching,
            missing_skills=missing,
            cover_letter="",
            status="sent" if result["success"] else "failed",
            fail_reason=result.get("fail_reason"),
            approved_by_user=approved_by_user,
        )
        if result["success"]:
            mark_applied(post_id)
        return result["success"]

    # ── No actionable contact info extracted ──────────────────
    print(f"   ⚠️  No email or link found for: {title} @ {company} — notify for manual apply")
    notify_external_failed(
        title, company,
        post.get("external_link") or "N/A",
        "no_contact_info_extracted",
        score,
    )
    return False


def run_agent():
    print("\n" + "=" * 60)
    print(f"  JOB AGENT — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    mode = "APPROVAL MODE" if APPROVAL_MODE else "AUTO MODE"
    print(f"  Mode: {mode}")
    print("=" * 60)

    init_database()
    reset_quota_flag()
    resume_data = load_resume_data()
    print(f"✅ Resume: {resume_data.get('full_name')}")

    # Process any outstanding WhatsApp replies first
    print("\n📲 Checking WhatsApp replies...")
    counts = receive_and_process_replies()
    if sum(counts.values()):
        print(f"   YES:{counts['yes']}  NO:{counts['no']}  ANS:{counts['ans']}")

    # Expire old unanswered approvals
    expired = expire_old_approvals(APPROVAL_TIMEOUT_SECONDS)
    if expired:
        print(f"   ⏰ {expired} old approval(s) timed out")

    stats = {
        "scanned":          0,
        "blocked":          0,
        "location_skipped": 0,
        "score_skipped":    0,
        "matched":          0,
        "pending_approval": 0,
        "emails_sent":      0,
        "emails_failed":    0,
        "external_ok":      0,
        "external_failed":  0,
        "shortlist_count":  0,
    }
    matched_posts_log = []   # track title+url for WhatsApp summary

    # Kill any stale Chrome/ChromeDriver processes from previous runs
    subprocess.run(["taskkill", "/F", "/IM", "chrome.exe"],
                   capture_output=True)
    subprocess.run(["taskkill", "/F", "/IM", "chromedriver.exe"],
                   capture_output=True)
    # Give Windows time to release file handles before profile cleanup
    time.sleep(2)

    driver = None
    try:
        driver = create_driver()
        if not login(driver):
            print("❌ Login failed — check .env credentials")
            return

        # ── Phase 1: Job listings → shortlist ─────────────────
        print("\n📋 PHASE 1: Scanning job listings...")
        matched_jobs, p1_scanned, p1_blocked, p1_skipped = scan_job_listings(driver, resume_data)
        stats["scanned"]        += p1_scanned
        stats["blocked"]        += p1_blocked
        stats["score_skipped"]  += p1_skipped
        stats["matched"]        += len(matched_jobs)
        stats["shortlist_count"] = min(
            len(matched_jobs), EASY_APPLY_SHORTLIST_SIZE
        )

        shortlist = matched_jobs[:EASY_APPLY_SHORTLIST_SIZE]
        if shortlist:
            html     = generate_shortlist_html(shortlist, resume_data)
            abs_path = os.path.abspath(SHORTLIST_PATH)
            with open(abs_path, "w", encoding="utf-8") as f:
                f.write(html)
            notify_shortlist_ready(len(shortlist), abs_path, shortlist)
            webbrowser.open(f"file:///{abs_path.replace(os.sep, '/')}")
            print(f"✅ Shortlist opened: {abs_path}")
            for j in shortlist:
                matched_posts_log.append({
                    "title":   j.get("title") or j.get("job_title", ""),
                    "company": j.get("company") or j.get("company_name", ""),
                    "url":     j.get("url", ""),
                    "score":   j.get("match_score", 0),
                    "method":  "easy_apply",
                })

        # ── Phase 2: Feed posts ────────────────────────────────
        print("\n📰 PHASE 2: Scanning LinkedIn feed posts...")
        feed_posts = scan_feed_posts(driver, resume_data)
        driver.quit()
        driver = None

        print(f"\n⚙️  PHASE 3: Processing {len(feed_posts)} matched posts...")

        apps_done = 0

        for idx, post in enumerate(feed_posts):
            if apps_done >= MAX_APPLICATIONS_PER_RUN:
                print(f"Max applications reached: {MAX_APPLICATIONS_PER_RUN}")
                break

            title   = post.get("job_title",    "Position")
            company = post.get("company_name", "Company")
            post_id = post.get("post_id",      "")

            stats["scanned"] += 1

            # ── Block: current/past company ────────────────────
            if is_company_blocked(company):
                print(f"   🚫 Blocked company: {company} — skipping")
                mark_skipped(post_id, "blocked_company")
                notify_company_blocked(title, company)
                stats["blocked"] += 1
                continue

            # ── Block: wrong location ──────────────────────────
            match_result = post.get("match_result") or post
            if not match_result.get("location_allowed", True):
                print(
                    f"   📍 Wrong location: "
                    f"{post.get('location','')} — skipping"
                )
                mark_skipped(post_id, "location_mismatch")
                stats["location_skipped"] += 1
                continue

            # ── Block: low score ───────────────────────────────
            score = match_result.get("match_score", 0)
            if not match_result.get("should_apply", False):
                reason = match_result.get("reject_reason", "low_score")
                print(
                    f"   📉 Score {score}% — "
                    f"{reason} — skipping"
                )
                mark_skipped(post_id, reason)
                stats["score_skipped"] += 1
                continue

            stats["matched"] += 1

            # ── Approval Mode: ask user first ──────────────────
            if APPROVAL_MODE:
                email  = post.get("email_to_apply")
                link   = post.get("external_link")
                method = post.get("apply_method", "unclear")
                target = email if method == "email" else (link or "")

                matching = (
                    match_result.get("skills", {})
                               .get("candidate_has", [])
                )
                missing = (
                    match_result.get("skills", {})
                               .get("candidate_missing", [])
                )

                # Best URL for this post: external link, else email, else N/A
                best_url = (
                    post.get("external_link")
                    or (f"mailto:{email}" if email else None)
                    or "N/A"
                )

                # Add to queue and send WhatsApp request
                add_to_approval_queue(
                    job_id=post_id,
                    title=title,
                    company=company,
                    location=post.get("location", ""),
                    url=best_url,
                    apply_method=method,
                    apply_target=target,
                    description=post.get("job_description", ""),
                    recruiter=post.get("poster_name", ""),
                    match_score=score,
                    matching_skills=matching,
                    missing_skills=missing,
                )

                send_approval_request(
                    job_id=post_id,
                    job_title=title,
                    company=company,
                    location=post.get("location", ""),
                    url=best_url,
                    apply_method=method,
                    apply_target=target,
                    match_score=score,
                    matching_skills=matching,
                    missing_skills=missing,
                    recruiter=post.get("poster_name", ""),
                )
                matched_posts_log.append({
                    "title":   title,
                    "company": company,
                    "url":     best_url,
                    "score":   score,
                    "method":  method,
                })

                print(f"   🔔 Approval sent for: {title} @ {company}")
                print(f"      Waiting for your WhatsApp reply...")

                # Wait for YES/NO
                decision = _wait_for_approval(
                    post_id, APPROVAL_TIMEOUT_SECONDS
                )

                if decision == "yes":
                    print(f"   ✅ Approved! Applying...")
                    ok = _execute_application(
                        post, resume_data, approved_by_user=True
                    )
                    if ok:
                        apps_done += 1
                        stats["emails_sent"] += (
                            1 if post.get("apply_method") == "email"
                            else 0
                        )
                        stats["external_ok"] += (
                            1 if post.get("apply_method") != "email"
                            else 0
                        )
                    else:
                        stats["emails_failed"] += (
                            1 if post.get("apply_method") == "email"
                            else 0
                        )
                        stats["external_failed"] += (
                            1 if post.get("apply_method") != "email"
                            else 0
                        )

                elif decision == "no":
                    print(f"   🚫 You rejected: {title} @ {company}")
                    mark_skipped(post_id, "user_rejected")

                else:  # timeout
                    print(f"   ⏰ Timed out: {title} @ {company}")
                    mark_skipped(post_id, "approval_timeout")
                    notify_approval_timeout(title, company, post_id)
                    stats["pending_approval"] += 1

            # ── Auto Mode: apply directly ──────────────────────
            else:
                print(f"   🤖 Auto-applying: {title} @ {company}")
                ok = _execute_application(
                    post, resume_data, approved_by_user=False
                )
                if ok:
                    apps_done += 1
                    stats["emails_sent"] += (
                        1 if post.get("apply_method") == "email" else 0
                    )
                    stats["external_ok"] += (
                        1 if post.get("apply_method") != "email" else 0
                    )
                else:
                    stats["emails_failed"] += (
                        1 if post.get("apply_method") == "email" else 0
                    )
                    stats["external_failed"] += (
                        1 if post.get("apply_method") != "email" else 0
                    )

            # ── Gap between applications ───────────────────────
            # Only wait if there are more posts to process and limit not hit
            remaining = len(feed_posts) - idx - 1
            if apps_done > 0 and apps_done < MAX_APPLICATIONS_PER_RUN and remaining > 0:
                _apply_gap()

        # ── Daily summary ──────────────────────────────────────
        notify_daily_summary(
            scanned=stats["scanned"],
            blocked=stats["blocked"],
            location_skipped=stats["location_skipped"],
            score_skipped=stats["score_skipped"],
            matched=stats["matched"],
            pending_approval=stats["pending_approval"],
            emails_sent=stats["emails_sent"],
            emails_failed=stats["emails_failed"],
            external_ok=stats["external_ok"],
            external_failed=stats["external_failed"],
            shortlist_count=stats["shortlist_count"],
            approval_mode=APPROVAL_MODE,
            matched_jobs=matched_posts_log,
        )

        print("\n" + "=" * 60)
        print("  AGENT COMPLETE")
        for k, v in stats.items():
            print(f"  {k:25} {v}")
        print("=" * 60)

    except Exception as e:
        print(f"❌ Agent error: {e}")
        import traceback
        traceback.print_exc()

    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass


if __name__ == "__main__":
    run_agent()