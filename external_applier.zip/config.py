# ═══════════════════════════════════════════════════════════
#  JOB AGENT CONFIGURATION
#  Profile: Muhammad Bilal — .NET Core / C# / Angular
# ═══════════════════════════════════════════════════════════

# ── Job Search Keywords ─────────────────────────────────────
# BUG FIX: Removed "Python Developer" and "Backend Developer"
# These keywords return irrelevant jobs (Ruby, Java, Node, PHP).
# Your core stack is .NET/C#/Angular — keywords must reflect that.
JOB_KEYWORDS = [
    ".NET Developer",
    "C# Developer",
    "ASP.NET Developer",
    "Full Stack Developer .NET",
    "Software Engineer .NET",
    "Angular Developer",
    ".NET Core Developer",
    "C# Angular Developer",
]

# ── Location Filter ─────────────────────────────────────────
ALLOWED_LOCATIONS = [
    "pakistan", "lahore", "faisalabad", "karachi", "islamabad",
    "rawalpindi", "remote", "work from home",
    "wfh", "anywhere", "worldwide", "global",
]

# Used by linkedin_reader.py for the LinkedIn search URLs
JOB_SEARCH_LOCATIONS = ["Pakistan", "Remote", "Lahore"]

# Alias so both names work (some files import JOB_LOCATIONS)
JOB_LOCATIONS = JOB_SEARCH_LOCATIONS

# ── Companies to NEVER apply to ─────────────────────────────
BLOCKED_COMPANIES = [
    "curemd",
]

# ── Matching Thresholds ─────────────────────────────────────
MIN_MATCH_SCORE               = 65
MIN_EXPERIENCE_RATIO          = 0.7
MIN_MUST_HAVE_SKILLS_COVERAGE = 0.6

# BUG FIX: Was missing — caused NameError in ai_engine.py
# Posts shorter than 300 chars use lighter (sparse) matching rules
SPARSE_POST_THRESHOLD = 300

# ── Application Mode ─────────────────────────────────────────
# True  → Agent asks YES/NO on WhatsApp before every application
#         USE THIS for week 1 to verify accuracy
# False → Agent applies automatically (switch after week 1)
APPROVAL_MODE = True

# Wait time for your WhatsApp YES/NO reply before auto-skip (seconds)
APPROVAL_TIMEOUT_SECONDS = 3600   # 1 hour

# ── Application Settings ─────────────────────────────────────
APPLY_VIA_EMAIL          = True
APPLY_VIA_EXTERNAL_FORMS = True
MAX_APPLICATIONS_PER_RUN = 15

# ── Gap Between Applications ─────────────────────────────────
MIN_GAP_BETWEEN_APPLIES_SEC = 120   # 2 minutes
MAX_GAP_BETWEEN_APPLIES_SEC = 300   # 5 minutes

# ── Shortlist (Easy Apply — you click manually) ───────────────
EASY_APPLY_SHORTLIST_SIZE = 10

# ── Auto-Schedule ─────────────────────────────────────────────
SCHEDULE_TIMES = ["09:00", "18:00"]

# ── File Paths ────────────────────────────────────────────────
RESUME_PDF_PATH  = "my_resume.pdf"
RESUME_DATA_PATH = "resume_data.json"
DATABASE_PATH    = "agent_memory.db"
SHORTLIST_PATH   = "todays_shortlist.html"
