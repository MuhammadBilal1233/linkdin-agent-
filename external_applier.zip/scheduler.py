"""
Runs the agent automatically on a schedule.
Keep this terminal open — it runs the agent at 9:00 AM and 6:00 PM daily
and checks WhatsApp replies every 2 minutes.

BUG FIX: receive_and_process_replies() returns a dict {"yes":N,"no":N,"ans":N}.
         The old code did `if count:` — a dict is always truthy so it printed
         every 2 minutes even when nothing happened.
         Fixed: use sum(counts.values()) to get the actual number.
"""

import schedule
import time
from main_agent import run_agent
from whatsapp_handler import receive_and_process_replies
from config import SCHEDULE_TIMES


def run_agent_safely():
    try:
        print("\n⏰ Scheduled agent run starting...")
        run_agent()
    except Exception as e:
        print(f"Scheduled run error: {e}")


def check_replies_safely():
    try:
        counts = receive_and_process_replies()
        total  = sum(counts.values())   # ← FIX: was `if count:` treating dict as int
        if total:
            print(
                f"📲 {total} replies processed — "
                f"YES:{counts['yes']}  NO:{counts['no']}  ANS:{counts['ans']}"
            )
    except Exception as e:
        print(f"Reply check error: {e}")


for run_time in SCHEDULE_TIMES:
    schedule.every().day.at(run_time).do(run_agent_safely)
    print(f"✅ Agent scheduled at {run_time} daily")

schedule.every(2).minutes.do(check_replies_safely)
print("✅ WhatsApp reply checker: every 2 minutes")

print(f"\n🤖 Scheduler running. Runs at: {SCHEDULE_TIMES}")
print("   Press Ctrl+C to stop\n")

while True:
    schedule.run_pending()
    time.sleep(30)
