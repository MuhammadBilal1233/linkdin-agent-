import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from dotenv import load_dotenv

load_dotenv()

def send_resume_email(to_email: str, recruiter_name: str, 
                      job_title: str, company_name: str,
                      resume_path: str, resume_data: dict) -> bool:
    """
    Send resume to recruiter via email.
    Uses your Gmail with App Password (free).
    """
    
    your_name = resume_data.get("full_name", "Applicant")
    your_email = os.getenv("YOUR_EMAIL")
    your_password = os.getenv("YOUR_EMAIL_APP_PASSWORD") or os.getenv("YOUR_EMAIL_PASSWORD")
    
    # Personalized subject line
    subject = f"Application for {job_title} – {your_name}"
    
    # Personalized body
    greeting = f"Dear {recruiter_name}," if recruiter_name else "Dear Hiring Manager,"
    
    body = f"""
{greeting}

I am writing to express my interest in the {job_title} position at {company_name}.

With {resume_data.get('years_of_experience', 'several')} years of experience in {resume_data.get('current_job_title', 'software development')}, I have developed strong expertise in {', '.join(resume_data.get('skills', ['relevant technologies'])[:5])}.

Please find my resume attached. I would welcome the opportunity to discuss how my background aligns with your team's needs.

Thank you for your time and consideration.

Best regards,
{your_name}
{resume_data.get('phone', '')}
{your_email}
{resume_data.get('linkedin_url', '')}
    """.strip()
    
    # Create email
    msg = MIMEMultipart()
    msg["From"] = your_email
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))
    
    # Attach resume PDF
    try:
        with open(resume_path, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            resume_filename = f"Resume_{your_name.replace(' ', '_')}.pdf"
            part.add_header(
                "Content-Disposition",
                f"attachment; filename={resume_filename}"
            )
            msg.attach(part)
    except FileNotFoundError:
        print(f"Resume file not found: {resume_path}")
        return False
    
    # Send via Gmail SMTP
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(your_email, your_password)
        server.sendmail(your_email, to_email, msg.as_string())
        server.quit()
        print(f"Email sent to {to_email} for {job_title} at {company_name}")
        return True
    except Exception as e:
        print(f"Email send failed: {e}")
        return False