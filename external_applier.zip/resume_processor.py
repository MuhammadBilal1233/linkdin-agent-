"""
Run this ONCE to parse your resume.
After that the agent reads resume_data.json automatically.

Migrated to new google-genai SDK (v1 API).
"""

import PyPDF2
import json
import os
from google import genai
from dotenv import load_dotenv

load_dotenv()

_api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
_client  = genai.Client(api_key=_api_key)

MODEL = "gemini-2.0-flash"


def extract_text_from_pdf(pdf_path: str) -> str:
    text = ""
    try:
        with open(pdf_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
    except Exception as e:
        print(f"Error reading PDF: {e}")
        raise
    return text


def _clean_json(raw: str) -> str:
    raw = (raw or "").strip()
    if "```json" in raw:
        raw = raw.split("```json", 1)[1].split("```", 1)[0]
    elif "```" in raw:
        raw = raw.split("```", 1)[1].split("```", 1)[0]
    return raw.strip()


def parse_resume(resume_text: str) -> dict:
    prompt = f"""Extract ALL information from this resume. Return ONLY valid JSON, no markdown, no explanation.

{{
  "full_name": "string",
  "email": "string",
  "phone": "string",
  "location": "string",
  "city": "string",
  "country": "string",
  "linkedin_url": "string or null",
  "website": "string or null",
  "years_of_experience": <number>,
  "current_job_title": "string",
  "professional_summary": "string",
  "skills": ["list"],
  "programming_languages": ["list"],
  "frameworks": ["list"],
  "databases": ["list"],
  "cloud_platforms": ["list"],
  "tools": ["list"],
  "education": [{{"degree":"","field":"","institution":"","year_end":"","gpa":""}}],
  "work_experience": [{{"title":"","company":"","location":"","start_date":"","end_date":"","description":"","achievements":[]}}],
  "certifications": [],
  "languages_spoken": [],
  "projects": [{{"name":"","description":"","technologies":[]}}],
  "notice_period": null,
  "expected_salary": null,
  "visa_status": null
}}

Resume:
{resume_text}"""

    response = _client.models.generate_content(model=MODEL, contents=prompt)
    raw = _clean_json(response.text or "")
    return json.loads(raw or "{}")


def save_resume_data(data: dict, path: str):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_resume_data(path: str = "resume_data.json") -> dict:
    if not os.path.exists(path):
        print(f"❌ Resume data file not found: {path}")
        print("   Run 'python resume_processor.py' first to parse your resume.")
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


if __name__ == "__main__":
    from config import RESUME_PDF_PATH, RESUME_DATA_PATH

    print(f"Reading: {RESUME_PDF_PATH}")
    text = extract_text_from_pdf(RESUME_PDF_PATH)
    print(f"Extracted {len(text)} characters")

    print("Parsing with Gemini...")
    data = parse_resume(text)
    save_resume_data(data, RESUME_DATA_PATH)

    print(f"\n✅ Saved to {RESUME_DATA_PATH}")
    print(f"  Name:       {data.get('full_name')}")
    print(f"  Title:      {data.get('current_job_title')}")
    print(f"  Experience: {data.get('years_of_experience')} years")
    print(f"  Skills:     {', '.join(data.get('skills', [])[:8])}")
