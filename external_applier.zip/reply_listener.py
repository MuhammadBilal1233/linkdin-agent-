"""
Standalone WhatsApp reply listener.
Run in a separate terminal for continuous reply checking without the scheduler.
"""

import time
import schedule
from whatsapp_handler import receive_and_process_replies


def check_replies():
    try:
        counts = receive_and_process_replies()
        total  = sum(counts.values())
        if total:
            print(
                f"📲 {total} replies — "
                f"YES:{counts['yes']}  NO:{counts['no']}  ANS:{counts['ans']}"
            )
    except Exception as e:
        print(f"Reply check error: {e}")


schedule.every(2).minutes.do(check_replies)

print("✅ WhatsApp reply listener running (checks every 2 min)")
print("Commands:  YES <job_id>  |  NO <job_id>  |  ANS <id> <answer>")
print("Press Ctrl+C to stop\n")

while True:
    schedule.run_pending()
    time.sleep(30)
