"""
Read-only LinkedIn access.
NEVER clicks Apply on LinkedIn — only reads and extracts.

LOGIN FIX (root cause of "Login page did not load" error):
  The old code did driver.get("/login") then immediately tried
  find_element(By.ID, "username"). LinkedIn sometimes:
    - Redirects /login → /login/ (trailing slash, same page)
    - Redirects /login → /uas/login (different page, same fields)
    - Loads slowly enough that the field isn't in the DOM yet
  
  All of these caused NoSuchElementException or the login page 
  appearing to "not load" even though it was loading fine.

  Fix: WebDriverWait(driver, 25) waits up to 25 seconds polling
  every 500ms. Also tries multiple CSS selectors for the username
  field to handle different LinkedIn login page variants.

Other fixes already in this file:
  - match_result stored in scan_feed_posts() return dict
  - job_location passed to match_job_to_resume() in feed scan
  - is_company_blocked() called before AI matching in feed scan
  - Chrome crash-prevention flags in create_driver()
"""

import time
import random
import hashlib
import os
import shutil
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException, StaleElementReferenceException
from webdriver_manager.chrome import ChromeDriverManager
from dotenv import load_dotenv

from ai_engine import match_job_to_resume, extract_job_details_from_post
from database import has_seen_job, save_job, is_company_blocked
from config import JOB_KEYWORDS, JOB_SEARCH_LOCATIONS, MIN_MATCH_SCORE

load_dotenv()

LINKEDIN_EMAIL    = os.getenv("LINKEDIN_EMAIL")
LINKEDIN_PASSWORD = os.getenv("LINKEDIN_PASSWORD")


def _delay(a=2, b=6):
    time.sleep(random.uniform(a, b))


def _job_id(url: str) -> str:
    return hashlib.md5(url.encode()).hexdigest()[:16]


def create_driver():
    """
    Chrome with crash-prevention flags.
    FIXES:
    - Removed --remote-debugging-port: causes SessionNotCreatedException when
      the port is already in use from a previous/parallel Chrome instance.
    - Added unique --user-data-dir per run: prevents profile lock conflicts
      between consecutive runs without a clean shutdown.
    - Removed useAutomationExtension: deprecated and causes errors in Chrome 110+.
    """
    options = Options()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_argument("--window-size=1366,768")
    options.add_argument("--disable-background-networking")
    options.add_argument("--disable-default-apps")
    # Fixed named profile dir — cleared each run to avoid stale Chrome profile locks
    CHROME_PROFILE_DIR = os.path.join(os.path.dirname(__file__), ".chrome_profile")
    if os.path.exists(CHROME_PROFILE_DIR):
        # Retry cleanup — Windows may still hold file handles briefly after taskkill
        for attempt in range(5):
            try:
                shutil.rmtree(CHROME_PROFILE_DIR)
                break
            except (PermissionError, OSError):
                # Remove lock files that prevent cleanup, then retry
                for lockfile in ("DevToolsActivePort", "SingletonLock",
                                 "SingletonCookie", "SingletonSocket"):
                    try:
                        os.remove(os.path.join(CHROME_PROFILE_DIR, lockfile))
                    except OSError:
                        pass
                time.sleep(1)
        # Final fallback: if rmtree failed, try once more ignoring errors
        if os.path.exists(CHROME_PROFILE_DIR):
            shutil.rmtree(CHROME_PROFILE_DIR, ignore_errors=True)
    os.makedirs(CHROME_PROFILE_DIR, exist_ok=True)
    options.add_argument(f"--user-data-dir={CHROME_PROFILE_DIR}")
    options.add_argument("--disable-background-timer-throttling")
    options.add_argument(
        "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    )
    service = Service(ChromeDriverManager().install())
    driver  = webdriver.Chrome(service=service, options=options)
    driver.execute_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    return driver


_EMAIL_SELECTORS = [
    (By.ID,          "username"),
    (By.NAME,        "session_key"),
    (By.CSS_SELECTOR, "input[autocomplete='username']"),
    (By.CSS_SELECTOR, "input[name='session_key']"),
    (By.CSS_SELECTOR, "input[type='email']"),
    (By.CSS_SELECTOR, "input[id*='email']"),
    (By.CSS_SELECTOR, "input[id*='username']"),
]

_PASSWORD_SELECTORS = [
    (By.ID,          "password"),
    (By.NAME,        "session_password"),
    (By.CSS_SELECTOR, "input[autocomplete='current-password']"),
    (By.CSS_SELECTOR, "input[name='session_password']"),
    (By.CSS_SELECTOR, "input[type='password']"),
]


def _wait_for_field(driver, selectors: list, timeout: int = 30):
    """
    Wait up to `timeout` seconds for any of the given (By, selector) pairs
    to become visible in the DOM. Returns the element or None.
    Uses WebDriverWait + EC which is resilient to StaleElementReferenceException.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        for by, selector in selectors:
            try:
                el = WebDriverWait(driver, 2).until(
                    EC.visibility_of_element_located((by, selector))
                )
                if el and el.is_displayed():
                    return el
            except (TimeoutException, NoSuchElementException,
                    StaleElementReferenceException):
                continue
        time.sleep(0.5)
    return None


def _find_email_field(driver):
    return _wait_for_field(driver, _EMAIL_SELECTORS, timeout=5)


def _find_password_field(driver):
    return _wait_for_field(driver, _PASSWORD_SELECTORS, timeout=5)


def login(driver) -> bool:
    """
    Log into LinkedIn.

    ROOT CAUSE OF "Login page did not load" ERROR:
    The URL https://www.linkedin.com/login/ (with trailing slash) shows
    the LinkedIn sign-in page fine, but the old code checked if the URL
    matched exactly "login" in the string, then immediately tried
    find_element which failed if the DOM wasn't ready yet.

    FIX: Use WebDriverWait to wait up to 25 seconds for the email field
    to actually appear in the DOM before trying to interact with it.
    Also handles the case where LinkedIn redirects to /uas/login.
    """
    print("🔐 Logging into LinkedIn...")

    try:
        driver.get("https://www.linkedin.com/login")

        # Short pause to let any redirects settle
        time.sleep(2)

        url = driver.current_url.lower()

        # If already logged in — LinkedIn redirects to /feed
        if any(x in url for x in ["feed", "mynetwork", "jobs", "messaging"]):
            print("✅ Already logged in")
            return True

        # Wait up to 30 seconds for the email field using WebDriverWait.
        # Handles slow networks, cookie banners, /login/ and /uas/login variants.
        # Also checks mid-wait if LinkedIn has already redirected to feed.
        email_field = None
        deadline    = time.time() + 30

        while time.time() < deadline:
            url = driver.current_url.lower()
            if any(x in url for x in ["feed", "mynetwork"]):
                print("✅ Already logged in (redirected)")
                return True
            if "challenge" in url or "checkpoint" in url:
                print("⚠️  Challenge/CAPTCHA detected — solve it in the browser")
                input("Press Enter after solving to continue...")
                return True
            email_field = _find_email_field(driver)
            if email_field:
                break
            time.sleep(1)

        if not email_field:
            print(f"❌ Email field not found after 30s. URL: {driver.current_url}")
            print("   Page source snippet:")
            try:
                print("  ", driver.page_source[:500])
            except Exception:
                pass
            print("   LinkedIn may have changed its login page. Try logging in manually.")
            return False

        # Type email with human-like timing
        email_field.clear()
        for c in LINKEDIN_EMAIL:
            email_field.send_keys(c)
            time.sleep(random.uniform(0.04, 0.10))

        time.sleep(random.uniform(0.5, 1.2))

        # Find and fill password field
        pw_field = _wait_for_field(driver, _PASSWORD_SELECTORS, timeout=10)

        if not pw_field:
            print("❌ Password field not found")
            return False

        pw_field.clear()
        for c in LINKEDIN_PASSWORD:
            pw_field.send_keys(c)
            time.sleep(random.uniform(0.04, 0.10))

        time.sleep(random.uniform(0.3, 0.8))
        pw_field.send_keys(Keys.RETURN)

        # Wait for post-login redirect (up to 20 seconds)
        try:
            WebDriverWait(driver, 20).until(
                lambda d: any(x in d.current_url.lower() for x in
                              ["feed", "checkpoint", "challenge",
                               "mynetwork", "jobs", "messaging", "captcha"])
            )
        except TimeoutException:
            pass   # Check manually below

        url = driver.current_url.lower()

        if any(x in url for x in ["feed", "mynetwork", "jobs", "messaging"]):
            print("✅ LinkedIn login successful")
            return True

        if "challenge" in url or "checkpoint" in url or "captcha" in url:
            print("⚠️  Security check — solve it in the browser window")
            print("   (Normal on first login or from a new IP address)")
            input("   Press Enter after solving to continue...")
            # Check again after solving
            url = driver.current_url.lower()
            if any(x in url for x in ["feed", "mynetwork", "jobs"]):
                print("✅ Login successful after security check")
            return True   # Give benefit of doubt

        if "login" in url or "signup" in url or "uas" in url:
            print("❌ Still on login page — wrong credentials?")
            print(f"   Check LINKEDIN_EMAIL and LINKEDIN_PASSWORD in .env")
            return False

        # Unknown URL — give benefit of doubt and proceed
        print(f"⚠️  Unexpected URL after login: {driver.current_url}")
        print("   Proceeding anyway...")
        return True

    except Exception as e:
        print(f"❌ Login error: {e}")
        return False


def scan_job_listings(driver, resume_data: dict) -> tuple:
    """
    Scan LinkedIn job listings (read-only).
    Returns matched jobs for the Easy Apply shortlist.
    """
    matched_jobs  = []
    total_scanned = 0
    total_blocked = 0
    total_skipped = 0

    for keyword in JOB_KEYWORDS:
        for location in JOB_SEARCH_LOCATIONS:
            print(f"\n🔍 Searching: {keyword} | {location}")

            url = (
                "https://www.linkedin.com/jobs/search/"
                f"?keywords={keyword.replace(' ', '%20')}"
                f"&location={location.replace(' ', '%20')}"
                f"&f_AL=true"
                f"&sortBy=DD"
            )

            driver.get(url)
            _delay(3, 5)

            for _ in range(3):
                driver.execute_script(
                    "window.scrollTo(0, document.body.scrollHeight);"
                )
                _delay(1.5, 2.5)

            job_links = set()
            for a in driver.find_elements(
                By.CSS_SELECTOR, "a[href*='/jobs/view/']"
            ):
                href = a.get_attribute("href") or ""
                if "/jobs/view/" in href:
                    job_links.add(href.split("?")[0])

            print(f"   Found {len(job_links)} job links")

            for job_url in list(job_links)[:15]:
                job_id = _job_id(job_url)

                if has_seen_job(job_id):
                    continue

                try:
                    driver.get(job_url)
                    _delay(2, 4)
                    total_scanned += 1

                    title = _safe_text(driver, [
                        "h1.job-details-jobs-unified-top-card__job-title",
                        "h1.t-24", "h1",
                    ])
                    company = _safe_text(driver, [
                        "a.job-details-jobs-unified-top-card__company-name",
                        ".topcard__org-name-link",
                        ".job-details-jobs-unified-top-card__company-name",
                    ])
                    description = _safe_text(driver, [
                        "#job-details",
                        ".jobs-description__content",
                        ".jobs-description",
                    ])
                    job_location = _safe_text(driver, [
                        ".job-details-jobs-unified-top-card__bullet",
                        ".topcard__flavor--bullet",
                    ])

                    if not title:
                        continue

                    if is_company_blocked(company):
                        print(f"   🚫 Blocked: {company}")
                        save_job(job_id, title, company, job_location,
                                 job_url, "linkedin_jobs", "blocked", 0)
                        total_blocked += 1
                        continue

                    match = match_job_to_resume(
                        title, description, resume_data,
                        job_location=job_location,
                        search_location=location,   # tells AI which location we searched
                    )
                    score = match.get("match_score", 0)

                    print(f"   {title[:38]:38} | {company[:18]:18} | Score: {score}%")

                    method = "easy_apply" if score >= MIN_MATCH_SCORE else "skip"
                    save_job(job_id, title, company, job_location,
                             job_url, "linkedin_jobs", method, score)

                    if score < MIN_MATCH_SCORE or not match.get("should_apply", False):
                        total_skipped += 1

                    if score >= MIN_MATCH_SCORE and match.get("should_apply", False):
                        matched_jobs.append({
                            "id":              job_id,
                            "post_id":         job_id,
                            "title":           title,
                            "job_title":       title,
                            "company":         company,
                            "company_name":    company,
                            "poster_name":     "",
                            "location":        job_location,
                            "url":             job_url,
                            "match_score":     score,
                            "match_result":    match,
                            "matching_skills": match.get("matching_skills", []),
                            "missing_skills":  match.get("missing_skills", []),
                            "reason":          match.get("reason", ""),
                        })

                    _delay(3, 6)

                except Exception as e:
                    print(f"   Error on job: {e}")
                    continue

            _delay(5, 10)

    matched_jobs.sort(key=lambda x: x["match_score"], reverse=True)
    print(f"\n📊 Scanned: {total_scanned} | Matched: {len(matched_jobs)} | Blocked: {total_blocked} | Skipped: {total_skipped}")
    return matched_jobs, total_scanned, total_blocked, total_skipped


def scan_feed_posts(driver, resume_data: dict) -> list:
    """
    Scan LinkedIn feed for posts with email or external apply links.
    match_result is stored in each returned post dict so main_agent.py
    can read it without KeyError.
    """
    print("\n📰 Scanning LinkedIn feed for job posts...")

    driver.get("https://www.linkedin.com/feed/")
    _delay(3, 5)

    actionable = []

    for _ in range(8):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        _delay(2, 3)

    posts = driver.find_elements(
        By.CSS_SELECTOR, ".feed-shared-update-v2, .occludable-update"
    )
    print(f"   Found {len(posts)} feed items")

    hire_keywords = [
        "hiring", "we're looking", "job opening", "position available",
        "send cv", "send resume", "apply to", "email your cv",
        "dm me", "careers@", "jobs@", "hr@", "apply now",
        "vacancy", "opportunity", "looking for a", "we need a",
        "join our team", "immediate opening", "urgent hiring",
    ]

    for post in posts[:50]:
        try:
            text = post.text
            if len(text) < 50:
                continue
            if not any(kw.lower() in text.lower() for kw in hire_keywords):
                continue

            info = extract_job_details_from_post(text)

            is_job = info.get("is_job_posting", info.get("is_job_post", False))
            if not is_job:
                continue

            has_email = bool(info.get("email_to_apply"))
            has_link  = bool(info.get("external_link"))
            if not (has_email or has_link):
                continue

            post_id = hashlib.md5(text[:200].encode()).hexdigest()[:16]
            if has_seen_job(post_id):
                continue

            company      = info.get("company_name") or "Unknown"
            job_location = info.get("location") or ""

            if is_company_blocked(company):
                print(f"   🚫 Blocked: {company}")
                continue

            match = match_job_to_resume(
                info.get("job_title") or "",
                (info.get("job_description") or "") + " " + text,
                resume_data,
                job_location=job_location,
                # Feed posts with no location are usually remote/worldwide — treat as Remote
                search_location=job_location or "Remote",
            )
            score = match.get("match_score", 0)

            save_job(
                post_id,
                info.get("job_title") or "Unknown",
                company, job_location,
                info.get("external_link") or "linkedin_feed",
                "feed_post",
                "email" if has_email else "external",
                score,
            )

            if score >= MIN_MATCH_SCORE and match.get("should_apply", False):
                info["post_id"]      = post_id
                info["match_score"]  = score
                info["match_result"] = match   # required by main_agent.py

                # Normalize: ai_engine returns 'application_method', main_agent reads 'apply_method'
                info["apply_method"] = info.get("application_method") or info.get("apply_method") or "unclear"

                info.setdefault("job_title",    info.get("job_title") or "Position")
                info.setdefault("company_name", company)
                info.setdefault("poster_name",  info.get("recruiter_name") or "")
                info.setdefault("location",     job_location)

                actionable.append(info)
                print(
                    f"   ✅ {info.get('job_title','?')} @ {company} | "
                    f"Score: {score}% | "
                    f"{'📧 email' if has_email else '🔗 link'}"
                )

        except Exception:
            continue

    print(f"   Actionable posts found: {len(actionable)}")
    return actionable


def _safe_text(driver, selectors: list) -> str:
    for sel in selectors:
        try:
            el   = driver.find_element(By.CSS_SELECTOR, sel)
            text = el.text.strip()
            if text:
                return text
        except Exception:
            pass
    return ""
